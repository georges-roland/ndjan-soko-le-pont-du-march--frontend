# 01 — Expo Go, pas à pas, sans ambiguïté

## Étape 1 — Dézipper
Décompresse le ZIP puis ouvre un terminal dans `ndjan_soko_project/mobile`.

## Étape 2 — Vérifier Node
```bash
node -v
npm -v
```

## Étape 3 — Trouver l'IP locale du PC
### Windows
```bash
ipconfig
```
### Mac / Linux
```bash
ifconfig
```
ou
```bash
ip addr
```

Cherche une IP du type `192.168.x.x`.

## Étape 4 — Remplacer l'IP dans le projet
Ouvre `mobile/app.json` et remplace l'URL :
```json
"apiBaseUrl": "http://192.168.1.100:8080"
```
par l'IP réelle de ton PC. Exemple :
```json
"apiBaseUrl": "http://192.168.1.20:8080"
```

## Étape 5 — Installer et lancer Expo
```bash
cd mobile
npm install
npx expo start -c
```

## Étape 6 — Sur le téléphone
1. installe **Expo Go**
2. mets le téléphone sur le **même Wi‑Fi** que le PC
3. ferme totalement une ancienne session Expo Go
4. scanne le **nouveau** QR code

## Résultat attendu
- splash avec le logo Ndjan-Soko
- onglets : Accueil, Utilisateurs, Marché, Tracking, Support, Facture
- bouton "Tester backend + catalogue"

## Si tu vois encore un ancien écran Expo
Refais exactement :
```bash
npx expo start -c
```
puis ferme Expo Go et rescane le nouveau QR code.
