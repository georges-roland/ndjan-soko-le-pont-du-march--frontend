# 04 — Play Store, pas à pas

## Étape 1 — Stabiliser Expo Go
Ne passe au Play Store qu'après avoir validé :
- UI
- backend
- tracking de base
- facture
- logo

## Étape 2 — Installer EAS CLI
```bash
npm install -g eas-cli
```

## Étape 3 — Te connecter
```bash
cd mobile
eas login
```

## Étape 4 — Configurer EAS
```bash
eas build:configure
```

## Étape 5 — Vérifier `app.json`
Vérifie surtout :
- nom = Ndjan-Soko
- package = `com.ndjansoko.app`
- logo / splash

## Étape 6 — Build Android
```bash
eas build --platform android --profile production
```
Tu récupéreras un `.aab`.

## Étape 7 — Google Play Console
1. Create app
2. nom = Ndjan-Soko
3. langue = Français
4. catégorie = Business ou Shopping
5. va dans Internal testing
6. crée une release
7. upload le `.aab`
8. ajoute les testeurs
9. publie le test interne

## Étape 8 — Assets Store
Utilise `playstore-assets/` pour démarrer tes visuels.

## Temps réaliste
- Expo Go local : 30 min à 2 h
- backend local : 30 min à 2 h
- intégrations réelles : 2 à 5 jours si tes accès sont déjà validés
- validation Google Play : quelques heures à plusieurs jours
