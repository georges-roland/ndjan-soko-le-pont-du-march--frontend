# 03 — Intégrations réelles, très concrètes

## Ordre recommandé
1. email transactionnel
2. WhatsApp Cloud API
3. Campay
4. Orange Money Business
5. Monetbil
6. dev build Expo

## A. Email transactionnel
### Où aller
- Resend
- ou Brevo

### Ce que tu fais là-bas
1. crée un compte
2. ajoute ton domaine, ex: `ndjansoko.com`
3. crée `hello@ndjansoko.com`
4. copie les enregistrements DNS affichés
5. colle-les chez ton registrar de domaine

### Où écrire les clés
Dans ton `.env` backend, en te basant sur `.env.example` :
```env
MAIL_PROVIDER=resend
MAIL_API_KEY=
MAIL_FROM=hello@ndjansoko.com
MAIL_REPLY_TO=support@ndjansoko.com
```

### Où brancher dans le code
- route actuelle : `POST /api/emails/welcome`
- fichier : `backend/src/main/java/com/ndjansoko/demo/web/ApiController.java`

## B. WhatsApp Cloud API
### Où aller
Va sur **Meta for Developers**.

### Ce que tu fais
1. crée une app
2. ajoute le produit WhatsApp
3. ouvre API Setup
4. relie ton WhatsApp Business Account
5. récupère `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_BUSINESS_ACCOUNT_ID`, token
6. crée un System User pour le token permanent
7. configure le webhook HTTPS public

### Variables à remplir
```env
WHATSAPP_ACCESS_TOKEN=
WHATSAPP_PHONE_NUMBER_ID=
WHATSAPP_BUSINESS_ACCOUNT_ID=
WHATSAPP_VERIFY_TOKEN=
WHATSAPP_WEBHOOK_SECRET=
```

### Où brancher dans le code
- route actuelle : `POST /api/notifications/whatsapp/send`
- ajoute aussi `GET /webhooks/whatsapp` et `POST /webhooks/whatsapp`

## C. Campay
1. crée le compte marchand Campay
2. récupère username / password / token
3. remplis `.env`
4. branche `POST /api/payments/campay/initiate`
5. ajoute le webhook Campay côté backend public

## D. Orange Money Business
1. termine l'onboarding marchand Orange
2. récupère `client id` et `client secret`
3. remplis `.env`
4. implémente `POST /api/payments/orange/initiate`

## E. Monetbil
1. crée ton service Monetbil
2. récupère `MONETBIL_SERVICE_KEY`
3. configure `notify_url`
4. branche le fallback paiement

## F. Agent IA support
La version locale répond déjà en temps réel via `POST /api/assistant/ask`.
Pour une vraie IA de production, remplace cette logique par un appel serveur vers ton fournisseur LLM.

## G. Tracking meilleur que Yango
- Expo Go : permission + position courante + démo backend
- prod : envoi de position, stockage PostGIS, ETA serveur, WebSocket/SSE
