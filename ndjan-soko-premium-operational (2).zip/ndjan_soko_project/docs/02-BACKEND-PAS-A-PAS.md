# 02 — Backend + base de données locale

## Ce que cette version utilise
- Spring Boot
- H2 en mémoire
- JPA
- Thymeleaf pour la facture

## Étape 1 — Vérifier Java
```bash
java -version
```
Recommandé : Java 21.

## Étape 2 — Lancer le backend
```bash
cd backend
mvn spring-boot:run
```

## Étape 3 — Tester dans le navigateur
- `http://localhost:8080/api/health`
- `http://localhost:8080/api/products`
- `http://localhost:8080/api/users`
- `http://localhost:8080/api/tracking/demo`
- `http://localhost:8080/api/invoices/demo`

## Étape 4 — Comprendre la base locale
Les produits et utilisateurs sont seedés au démarrage dans :
- `backend/src/main/java/com/ndjansoko/demo/config/DataInitializer.java`

## Étape 5 — Où sont les tables
- Produit : `model/Product.java`
- Utilisateur : `model/UserProfile.java`
- Repositories : `repo/`

## Si Expo ne parle pas au backend
Vérifie :
1. le backend tourne bien sur le port 8080
2. l'IP dans `mobile/app.json` est correcte
3. ton téléphone et ton PC sont sur le même réseau Wi‑Fi
