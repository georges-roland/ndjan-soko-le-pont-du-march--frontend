# 05 — Checklist finale

## Expo Go
- [ ] `npm install` exécuté dans mobile
- [ ] `npx expo start -c` lancé
- [ ] téléphone sur le même Wi‑Fi
- [ ] bonne IP locale dans `mobile/app.json`
- [ ] logo visible au splash

## Backend
- [ ] `mvn spring-boot:run` lancé
- [ ] `/api/health` répond
- [ ] `/api/products` répond
- [ ] `/api/users` répond
- [ ] `/api/tracking/demo` répond
- [ ] `/api/invoices/demo` répond

## Réel
- [ ] domaine email prêt
- [ ] compte WhatsApp Business prêt
- [ ] compte Campay prêt
- [ ] compte Orange prêt
- [ ] compte Monetbil prêt
- [ ] backend HTTPS public prêt
