package com.ndjansoko.demo.repo;

import com.ndjansoko.demo.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}
