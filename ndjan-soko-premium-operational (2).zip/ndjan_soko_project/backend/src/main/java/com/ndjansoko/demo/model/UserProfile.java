package com.ndjansoko.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UserProfile {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String fullName;
    private String role;
    private String city;
    private String phone;

    public UserProfile() {}

    public UserProfile(String fullName, String role, String city, String phone) {
        this.fullName = fullName;
        this.role = role;
        this.city = city;
        this.phone = phone;
    }

    public Long getId() { return id; }
    public String getFullName() { return fullName; }
    public String getRole() { return role; }
    public String getCity() { return city; }
    public String getPhone() { return phone; }
}
