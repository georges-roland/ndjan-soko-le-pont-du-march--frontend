package com.ndjansoko.demo.web;

import com.ndjansoko.demo.repo.ProductRepository;
import com.ndjansoko.demo.repo.UserProfileRepository;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.Map;

@Controller
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ApiController {
    private final ProductRepository productRepository;
    private final UserProfileRepository userProfileRepository;

    public ApiController(ProductRepository productRepository, UserProfileRepository userProfileRepository) {
        this.productRepository = productRepository;
        this.userProfileRepository = userProfileRepository;
    }

    @GetMapping("/health")
    @ResponseBody
    public Map<String, Object> health() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("status", "ok");
        map.put("service", "ndjan-soko-backend");
        map.put("database", "h2-memory");
        map.put("time", OffsetDateTime.now().toString());
        return map;
    }

    @GetMapping("/products")
    @ResponseBody
    public Map<String, Object> products() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("items", productRepository.findAll());
        map.put("count", productRepository.count());
        return map;
    }

    @GetMapping("/users")
    @ResponseBody
    public Map<String, Object> users() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("items", userProfileRepository.findAll());
        map.put("count", userProfileRepository.count());
        return map;
    }

    @GetMapping("/tracking/demo")
    @ResponseBody
    public Map<String, Object> trackingDemo() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("tripId", "TRIP-001");
        map.put("status", "EN_ROUTE");
        map.put("etaMinutes", 42);
        map.put("distanceKm", 18.4);
        map.put("driverLat", 4.0511);
        map.put("driverLng", 9.7679);
        return map;
    }

    @PostMapping(path = "/trips/{tripId}/location", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Map<String, Object> receiveLocation(@PathVariable String tripId, @RequestBody Map<String, Object> payload) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("ok", true);
        map.put("tripId", tripId);
        map.put("received", payload);
        map.put("nextStep", "Branche PostgreSQL/PostGIS + WebSocket pour le vrai temps réel multi-acteurs.");
        return map;
    }

    @PostMapping(path = "/assistant/ask", consumes = MediaType.APPLICATION_JSON_VALUE)
    @ResponseBody
    public Map<String, Object> askAssistant(@RequestBody Map<String, String> payload) {
        String q = payload.getOrDefault("question", "").toLowerCase();
        String answer;
        if (q.contains("livraison") || q.contains("tracking") || q.contains("où")) {
            answer = "La livraison est suivie par le transporteur. Dans cette version locale, ouvre l'onglet Tracking pour voir l'ETA et l'état EN_ROUTE. En production, relie ce flux à /api/trips/{tripId}/location avec WebSocket.";
        } else if (q.contains("payer") || q.contains("paiement") || q.contains("campay")) {
            answer = "Le tunnel de paiement réel se branche côté backend uniquement. Campay, Orange Money Business et Monetbil sont prévus via le fichier .env.example et des endpoints dédiés.";
        } else if (q.contains("compte") || q.contains("utilisateur") || q.contains("rôle")) {
            answer = "Les rôles déjà prévus sont Admin, Acheteur, Fournisseur, Transporteur et Hub. Le backend local expose /api/users pour les lister.";
        } else {
            answer = "Je suis l'assistant de support local Ndjan-Soko. Je connais les flux de l'app, les rôles, le marché, le tracking, la facture et le plan de branchement des services réels.";
        }
        return Map.of("ok", true, "answer", answer);
    }

    @GetMapping("/invoices/demo")
    public String invoice(Model model) {
        model.addAttribute("invoiceId", "NDJ-2026-001");
        model.addAttribute("customer", "Jean Buyer");
        model.addAttribute("product", "Tomates fraîches premium");
        model.addAttribute("amount", "125 000 FCFA");
        model.addAttribute("status", "Paiement sécurisé prêt à brancher via Campay / Orange / Monetbil.");
        return "invoice";
    }

    @PostMapping("/payments/campay/initiate")
    @ResponseBody
    public Map<String, Object> campay() {
        return Map.of("ok", true, "message", "Endpoint prêt. Branche Campay avec tes vraies clés ici.");
    }

    @PostMapping("/payments/orange/initiate")
    @ResponseBody
    public Map<String, Object> orange() {
        return Map.of("ok", true, "message", "Endpoint prêt. Branche Orange Money Business ici.");
    }

    @PostMapping("/payments/monetbil/initiate")
    @ResponseBody
    public Map<String, Object> monetbil() {
        return Map.of("ok", true, "message", "Endpoint prêt. Branche Monetbil ici.");
    }

    @PostMapping("/notifications/whatsapp/send")
    @ResponseBody
    public Map<String, Object> whatsapp() {
        return Map.of("ok", true, "message", "Endpoint prêt. Branche WhatsApp Cloud API ici.");
    }

    @PostMapping("/emails/welcome")
    @ResponseBody
    public Map<String, Object> emailWelcome() {
        return Map.of("ok", true, "message", "Endpoint prêt. Branche Resend ou Brevo ici.");
    }
}
