package com.ndjansoko.demo.config;

import com.ndjansoko.demo.model.Product;
import com.ndjansoko.demo.model.UserProfile;
import com.ndjansoko.demo.repo.ProductRepository;
import com.ndjansoko.demo.repo.UserProfileRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {
    @Bean
    CommandLineRunner init(ProductRepository products, UserProfileRepository users) {
        return args -> {
            if (products.count() == 0) {
                products.save(new Product("Tomates fraîches premium", "Lot groupé prêt à partir vers Douala.", "Moungo", "CAT_A", 700, 125000));
                products.save(new Product("Manioc sélectionné", "Récolte triée pour grossistes et supermarchés.", "Ouest", "CAT_A", 1200, 198000));
                products.save(new Product("Plantain export", "Qualité homogène pour hub logistique.", "Centre", "CAT_B", 850, 143500));
            }
            if (users.count() == 0) {
                users.save(new UserProfile("Aline Admin", "Admin", "Douala", "+237690000001"));
                users.save(new UserProfile("Jean Buyer", "Acheteur", "Yaoundé", "+237690000002"));
                users.save(new UserProfile("Mado Supplier", "Fournisseur", "Moungo", "+237690000003"));
                users.save(new UserProfile("Paul Driver", "Transporteur", "Bafoussam", "+237690000004"));
            }
        };
    }
}
