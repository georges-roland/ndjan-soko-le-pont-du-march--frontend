package com.ndjansoko.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    private String region;
    private String quality;
    private Integer quantityKg;
    private Integer priceFcfa;

    public Product() {}

    public Product(String name, String description, String region, String quality, Integer quantityKg, Integer priceFcfa) {
        this.name = name;
        this.description = description;
        this.region = region;
        this.quality = quality;
        this.quantityKg = quantityKg;
        this.priceFcfa = priceFcfa;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public String getDescription() { return description; }
    public String getRegion() { return region; }
    public String getQuality() { return quality; }
    public Integer getQuantityKg() { return quantityKg; }
    public Integer getPriceFcfa() { return priceFcfa; }
}
