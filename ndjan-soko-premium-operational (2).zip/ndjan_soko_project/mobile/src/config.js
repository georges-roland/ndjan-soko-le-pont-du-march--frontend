export const HELP_TEXT = [
  '1. Remplace l'IP 192.168.1.100 par l'IP locale réelle de ton PC dans app.json.',
  '2. Lance le backend sur le port 8080.',
  '3. Lance Expo avec npx expo start -c.',
  '4. Scanne le nouveau QR code avec Expo Go.'
];
