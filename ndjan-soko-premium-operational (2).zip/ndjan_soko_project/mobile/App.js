import React, { useMemo, useState } from 'react';
        import {
          ActivityIndicator,
          Alert,
          Image,
          Pressable,
          SafeAreaView,
          ScrollView,
          StyleSheet,
          Text,
          TextInput,
          View,
        } from 'react-native';
        import { StatusBar } from 'expo-status-bar';
        import Constants from 'expo-constants';
        import * as Location from 'expo-location';
        import { HELP_TEXT } from './src/config';

        const COLORS = {
          bg: '#F7F4ED',
          card: '#FFFFFF',
          line: '#E8E1D4',
          green: '#0B6B35',
          greenSoft: '#E7F4EB',
          orange: '#FF8B1F',
          orangeSoft: '#FFF1E3',
          blue: '#2E6DE6',
          blueSoft: '#EAF2FF',
          text: '#163226',
          muted: '#68786B',
        };

        const TABS = ['Accueil', 'Utilisateurs', 'Marché', 'Tracking', 'Support', 'Facture'];
        const ROLES = [
          { key: 'Admin', text: 'Supervise utilisateurs, incidents, paiements et support.', color: '#EFF3FF' },
          { key: 'Acheteur', text: 'Consulte le marché, commande et suit la livraison.', color: '#FFF3E7' },
          { key: 'Fournisseur', text: 'Publie les produits et suit les ventes.', color: '#EAF7EE' },
          { key: 'Transporteur', text: 'Partage sa position et livre les commandes.', color: '#EBF3FF' },
          { key: 'Hub', text: 'Valide les dépôts et coordonne le stock local.', color: '#F5EDFF' },
        ];

        function Pill({ label, active, onPress }) {
          return (
            <Pressable onPress={onPress} style={[styles.pill, active && styles.pillActive]}>
              <Text style={[styles.pillText, active && styles.pillTextActive]}>{label}</Text>
            </Pressable>
          );
        }

        function Section({ title, subtitle, children }) {
          return (
            <View style={{ marginBottom: 18 }}>
              <Text style={styles.sectionTitle}>{title}</Text>
              {!!subtitle && <Text style={styles.sectionSubtitle}>{subtitle}</Text>}
              <View style={{ marginTop: 10 }}>{children}</View>
            </View>
          );
        }

        function Card({ children, style }) {
          return <View style={[styles.card, style]}>{children}</View>;
        }

        export default function App() {
          const [tab, setTab] = useState('Accueil');
          const [health, setHealth] = useState(null);
          const [products, setProducts] = useState([]);
          const [tracking, setTracking] = useState(null);
          const [coords, setCoords] = useState(null);
          const [loading, setLoading] = useState(false);
          const [question, setQuestion] = useState('Comment fonctionne la livraison ?');
          const [answer, setAnswer] = useState('');

          const apiBaseUrl = useMemo(
            () => Constants.expoConfig?.extra?.apiBaseUrl || 'http://192.168.1.100:8080',
            []
          );

          const fetchJson = async (path, options = undefined) => {
            const res = await fetch(`${apiBaseUrl}${path}`, options);
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            return res.json();
          };

          const testerBackend = async () => {
            try {
              setLoading(true);
              const [h, p] = await Promise.all([
                fetchJson('/api/health'),
                fetchJson('/api/products'),
              ]);
              setHealth(h);
              setProducts(p.items || []);
            } catch (e) {
              Alert.alert('Backend inaccessible', `Erreur: ${e.message}

Vérifie app.json et l'IP locale.`);
            } finally {
              setLoading(false);
            }
          };

          const chargerTracking = async () => {
            try {
              setLoading(true);
              const data = await fetchJson('/api/tracking/demo');
              setTracking(data);
            } catch (e) {
              Alert.alert('Tracking indisponible', e.message);
            } finally {
              setLoading(false);
            }
          };

          const partagerPosition = async () => {
            try {
              setLoading(true);
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status !== 'granted') {
                Alert.alert('Permission refusée', 'Autorise la localisation dans Expo Go.');
                return;
              }
              const position = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              setCoords(position.coords);
            } catch (e) {
              Alert.alert('Erreur localisation', e.message);
            } finally {
              setLoading(false);
            }
          };

          const poserQuestion = async () => {
            try {
              setLoading(true);
              const data = await fetchJson('/api/assistant/ask', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question }),
              });
              setAnswer(data.answer || 'Aucune réponse');
            } catch (e) {
              Alert.alert('Assistant indisponible', e.message);
            } finally {
              setLoading(false);
            }
          };

          return (
            <SafeAreaView style={styles.safe}>
              <StatusBar style="dark" />
              <View style={styles.header}>
                <Image source={require('./assets/logo.jpg')} style={styles.logo} />
                <View style={{ flex: 1 }}>
                  <Text style={styles.brand}>Ndjan-Soko</Text>
                  <Text style={styles.tagline}>Le Pont du Marché</Text>
                </View>
              </View>

              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.pillRow}>
                {TABS.map((item) => (
                  <Pill key={item} label={item} active={tab === item} onPress={() => setTab(item)} />
                ))}
              </ScrollView>

              <ScrollView contentContainerStyle={styles.content}>
                {tab === 'Accueil' && (
                  <>
                    <Card style={{ padding: 18 }}>
                      <Text style={styles.heroTitle}>Version Expo Go fonctionnelle</Text>
                      <Text style={styles.bodyText}>
                        Cette base remplace l'écran Expo générique par une vraie interface Ndjan-Soko inspirée de tes maquettes.
                      </Text>
                      <Text style={styles.apiText}>API visée: {apiBaseUrl}</Text>
                      <Pressable style={styles.primaryBtn} onPress={testerBackend}>
                        {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Tester backend + catalogue</Text>}
                      </Pressable>
                    </Card>

                    <Section title="Checklist immédiate" subtitle="Ce qui doit marcher dès maintenant en local.">
                      {HELP_TEXT.map((item) => (
                        <Card key={item} style={{ marginBottom: 10, backgroundColor: COLORS.greenSoft }}>
                          <Text style={styles.bodyText}>{item}</Text>
                        </Card>
                      ))}
                    </Section>

                    <Section title="Référence visuelle" subtitle="Maquette principale intégrée directement dans l'app.">
                      <Image source={require('./assets/reference-main.jpg')} style={styles.referenceWide} resizeMode="cover" />
                    </Section>

                    {health && (
                      <Section title="Backend connecté" subtitle="Réponse reçue depuis Spring Boot.">
                        <Card style={{ backgroundColor: COLORS.blueSoft }}>
                          <Text style={styles.cardTitle}>Statut: {health.status}</Text>
                          <Text style={styles.bodyText}>Service: {health.service}</Text>
                          <Text style={styles.bodyText}>Base locale: {health.database}</Text>
                        </Card>
                      </Section>
                    )}
                  </>
                )}

                {tab === 'Utilisateurs' && (
                  <Section title="Multi-utilisateurs" subtitle="Exemples de rôles déjà prévus dans l'app et le backend.">
                    {ROLES.map((role) => (
                      <Card key={role.key} style={{ marginBottom: 10, backgroundColor: role.color }}>
                        <Text style={styles.cardTitle}>{role.key}</Text>
                        <Text style={styles.bodyText}>{role.text}</Text>
                      </Card>
                    ))}
                  </Section>
                )}

                {tab === 'Marché' && (
                  <Section title="Marché" subtitle="Les produits viennent du backend local H2 / JPA.">
                    {products.length === 0 ? (
                      <Card><Text style={styles.bodyText}>Appuie d'abord sur « Tester backend + catalogue » dans Accueil.</Text></Card>
                    ) : (
                      products.map((item) => (
                        <Card key={item.id} style={{ marginBottom: 10 }}>
                          <Text style={styles.cardTitle}>{item.name}</Text>
                          <Text style={styles.bodyText}>{item.description}</Text>
                          <Text style={styles.bodyText}>Région: {item.region} • Qualité: {item.quality}</Text>
                          <Text style={styles.price}>{item.priceFcfa.toLocaleString('fr-FR')} FCFA</Text>
                        </Card>
                      ))
                    )}
                  </Section>
                )}

                {tab === 'Tracking' && (
                  <>
                    <Section title="Tracking style Yango, mais meilleure base" subtitle="Expo Go pour la démo, dev build pour le fond de tâche ensuite.">
                      <Card>
                        <Pressable style={styles.primaryBtn} onPress={partagerPosition}>
                          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Partager ma position</Text>}
                        </Pressable>
                        <Pressable style={[styles.primaryBtn, { backgroundColor: COLORS.blue }]} onPress={chargerTracking}>
                          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Charger suivi démo</Text>}
                        </Pressable>

                        {coords && (
                          <View style={styles.infoBox}>
                            <Text style={styles.infoLine}>Latitude: {coords.latitude.toFixed(6)}</Text>
                            <Text style={styles.infoLine}>Longitude: {coords.longitude.toFixed(6)}</Text>
                            <Text style={styles.infoLine}>Précision: {Math.round(coords.accuracy || 0)} m</Text>
                          </View>
                        )}

                        {tracking && (
                          <View style={[styles.infoBox, { backgroundColor: COLORS.greenSoft, marginTop: 12 }]}>
                            <Text style={styles.infoLine}>Trip: {tracking.tripId}</Text>
                            <Text style={styles.infoLine}>Statut: {tracking.status}</Text>
                            <Text style={styles.infoLine}>ETA: {tracking.etaMinutes} min</Text>
                            <Text style={styles.infoLine}>Distance: {tracking.distanceKm} km</Text>
                          </View>
                        )}
                      </Card>
                    </Section>
                  </>
                )}

                {tab === 'Support' && (
                  <>
                    <Section title="Agent IA support" subtitle="Répond localement en temps réel aux questions fréquentes.">
                      <Image source={require('./assets/reference-support.jpg')} style={styles.referenceTall} resizeMode="cover" />
                      <Card style={{ marginTop: 12 }}>
                        <TextInput
                          value={question}
                          onChangeText={setQuestion}
                          placeholder="Pose une question"
                          style={styles.input}
                        />
                        <Pressable style={styles.primaryBtn} onPress={poserQuestion}>
                          {loading ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryBtnText}>Demander à l'assistant</Text>}
                        </Pressable>
                        {!!answer && <Text style={[styles.bodyText, { marginTop: 12 }]}>{answer}</Text>}
                      </Card>
                    </Section>
                  </>
                )}

                {tab === 'Facture' && (
                  <Section title="Facture" subtitle="Même logo dans l'app, la facture et les assets Play Store.">
                    <Card>
                      <View style={styles.invoiceRow}>
                        <Image source={require('./assets/logo.jpg')} style={styles.invoiceLogo} />
                        <View style={{ flex: 1 }}>
                          <Text style={styles.cardTitle}>Facture NDJ-2026-001</Text>
                          <Text style={styles.bodyText}>Client: Jean Buyer</Text>
                          <Text style={styles.bodyText}>Produit: Tomates fraîches premium</Text>
                          <Text style={styles.price}>125 000 FCFA</Text>
                        </View>
                      </View>
                      <Text style={[styles.bodyText, { marginTop: 12 }]}>Ouvre ensuite /api/invoices/demo dans le navigateur pour voir le rendu HTML serveur.</Text>
                    </Card>
                  </Section>
                )}
              </ScrollView>
            </SafeAreaView>
          );
        }

        const styles = StyleSheet.create({
          safe: { flex: 1, backgroundColor: COLORS.bg },
          header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 18, paddingTop: 16, paddingBottom: 10 },
          logo: { width: 60, height: 60, borderRadius: 18, marginRight: 12 },
          brand: { fontSize: 28, fontWeight: '800', color: COLORS.green },
          tagline: { color: COLORS.orange, fontWeight: '700' },
          pillRow: { paddingHorizontal: 14, paddingBottom: 8 },
          pill: { backgroundColor: '#EEE8DC', paddingVertical: 10, paddingHorizontal: 16, borderRadius: 999, marginRight: 8 },
          pillActive: { backgroundColor: COLORS.green },
          pillText: { color: COLORS.text, fontWeight: '700' },
          pillTextActive: { color: '#fff' },
          content: { padding: 16, paddingTop: 6 },
          sectionTitle: { fontSize: 20, fontWeight: '800', color: COLORS.text },
          sectionSubtitle: { color: COLORS.muted, marginTop: 4, lineHeight: 20 },
          card: { backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.line, borderRadius: 24, padding: 16 },
          heroTitle: { fontSize: 24, fontWeight: '800', color: COLORS.text, marginBottom: 8 },
          bodyText: { color: COLORS.muted, lineHeight: 21 },
          apiText: { marginTop: 10, color: COLORS.green, fontWeight: '700' },
          cardTitle: { fontSize: 18, fontWeight: '800', color: COLORS.text, marginBottom: 6 },
          price: { marginTop: 8, color: COLORS.orange, fontWeight: '800', fontSize: 18 },
          primaryBtn: { marginTop: 12, backgroundColor: COLORS.green, borderRadius: 16, paddingVertical: 14, alignItems: 'center' },
          primaryBtnText: { color: '#fff', fontWeight: '800' },
          infoBox: { marginTop: 12, backgroundColor: COLORS.blueSoft, borderRadius: 16, padding: 14 },
          infoLine: { color: COLORS.text, marginBottom: 5, fontWeight: '600' },
          referenceWide: { width: '100%', height: 200, borderRadius: 20 },
          referenceTall: { width: '100%', height: 360, borderRadius: 20 },
          input: { borderWidth: 1, borderColor: COLORS.line, borderRadius: 14, padding: 12, color: COLORS.text },
          invoiceRow: { flexDirection: 'row', alignItems: 'center' },
          invoiceLogo: { width: 58, height: 58, borderRadius: 14, marginRight: 12 },
        });
