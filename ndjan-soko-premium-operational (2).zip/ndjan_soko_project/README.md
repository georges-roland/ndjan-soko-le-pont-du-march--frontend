# Ndjan-Soko — pack Expo Go + backend local

Ce projet contient :
- `mobile/` : app Expo Go premium inspirée des maquettes
- `backend/` : API Spring Boot + H2 locale
- `branding/` : références visuelles utilisées
- `playstore-assets/` : assets de base pour la fiche Play Store
- `docs/` : guide pas à pas, très concret

## Objectif
Démarrer **vraiment** en local avec Expo Go d'abord, puis préparer le passage en build Android / Play Store.

## Important
- La version locale fonctionne sans clés tierces.
- Les intégrations **réelles** Campay / Monetbil / Orange Money / WhatsApp / email demandent encore tes vrais accès.
- Le projet est structuré pour les brancher proprement ensuite.
