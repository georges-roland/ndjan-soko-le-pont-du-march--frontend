@REM Maven Wrapper script for Windows
@echo off
setlocal

set MAVEN_PROJECTBASEDIR=%~dp0
set WRAPPER_PROPERTIES=%MAVEN_PROJECTBASEDIR%.mvn\wrapper\maven-wrapper.properties

for /f "tokens=2 delims==" %%A in ('findstr /i "distributionUrl" "%WRAPPER_PROPERTIES%"') do set DISTRIBUTION_URL=%%A
for %%F in ("%DISTRIBUTION_URL%") do set DISTRIBUTION_FILENAME=%%~nxF
set DISTRIBUTION_NAME=%DISTRIBUTION_FILENAME:-bin.zip=%

if not defined MAVEN_USER_HOME set MAVEN_USER_HOME=%USERPROFILE%\.m2
set WRAPPER_DIR=%MAVEN_USER_HOME%\wrapper
set MAVEN_HOME=%WRAPPER_DIR%\%DISTRIBUTION_NAME%

if not exist "%MAVEN_HOME%\bin\mvn.cmd" (
    echo Téléchargement de Maven ^(%DISTRIBUTION_NAME%^)...
    if not exist "%WRAPPER_DIR%" mkdir "%WRAPPER_DIR%"
    powershell -Command "Invoke-WebRequest -Uri '%DISTRIBUTION_URL%' -OutFile '%WRAPPER_DIR%\%DISTRIBUTION_FILENAME%'"
    powershell -Command "Expand-Archive -Path '%WRAPPER_DIR%\%DISTRIBUTION_FILENAME%' -DestinationPath '%WRAPPER_DIR%' -Force"
    del "%WRAPPER_DIR%\%DISTRIBUTION_FILENAME%"
    echo Maven installé dans %MAVEN_HOME%
)

"%MAVEN_HOME%\bin\mvn.cmd" %*
