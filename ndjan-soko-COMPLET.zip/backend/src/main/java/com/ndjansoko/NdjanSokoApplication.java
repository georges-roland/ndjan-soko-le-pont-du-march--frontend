package com.ndjansoko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class NdjanSokoApplication {
    public static void main(String[] args) {
        SpringApplication.run(NdjanSokoApplication.class, args);
    }
}
