package com.ndjansoko.config;

import com.ndjansoko.modules.auth.model.User;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Service JWT : génère et valide les tokens d'authentification.
 * RESPONSABLE : F
 *
 * Chaque token contient : phoneNumber, userId, role.
 * Durée de vie configurable dans application.properties (jwt.expiration-ms).
 */
@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secret;

    @Value("${jwt.expiration-ms}")
    private long expirationMs;

    // ─── Clé de signature ──────────────────────────────────────────────────────

    private SecretKey getSigningKey() {
        // La clé doit faire au moins 256 bits pour HMAC-SHA256
        byte[] keyBytes = secret.getBytes(StandardCharsets.UTF_8);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    // ─── Génération ────────────────────────────────────────────────────────────

    /**
     * Génère un JWT signé pour l'utilisateur donné.
     * Le token encode : sub (phoneNumber), userId, role, iat, exp.
     */
    public String generateToken(User user) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("userId", user.getId());
        claims.put("role",   user.getRole().name());
        claims.put("name",   user.getFullName() != null ? user.getFullName() : "");

        return Jwts.builder()
                .claims(claims)
                .subject(user.getPhoneNumber())
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + expirationMs))
                .signWith(getSigningKey())
                .compact();
    }

    // ─── Validation & extraction ────────────────────────────────────────────────

    /**
     * Valide le token et retourne les claims décodés.
     * Lève une JwtException si le token est invalide ou expiré.
     */
    public Claims validateAndExtract(String token) {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    /**
     * Extrait le numéro de téléphone (subject) du token.
     */
    public String extractPhone(String token) {
        return validateAndExtract(token).getSubject();
    }

    /**
     * Extrait le rôle encodé dans le token.
     */
    public String extractRole(String token) {
        return (String) validateAndExtract(token).get("role");
    }

    /**
     * Extrait l'ID utilisateur encodé dans le token.
     */
    public Long extractUserId(String token) {
        Object id = validateAndExtract(token).get("userId");
        if (id instanceof Integer) return ((Integer) id).longValue();
        return (Long) id;
    }

    /**
     * Vérifie rapidement si un token est encore valide (non expiré, signature OK).
     */
    public boolean isValid(String token) {
        try {
            validateAndExtract(token);
            return true;
        } catch (JwtException | IllegalArgumentException e) {
            return false;
        }
    }
}
