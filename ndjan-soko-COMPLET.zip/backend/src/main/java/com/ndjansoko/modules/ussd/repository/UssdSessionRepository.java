package com.ndjansoko.modules.ussd.repository;

import com.ndjansoko.modules.ussd.model.UssdSession;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Repository pour les sessions USSD.
 * RESPONSABLE : A
 */
@Repository
public interface UssdSessionRepository extends JpaRepository<UssdSession, Long> {
    Optional<UssdSession> findBySessionId(String sessionId);
}
