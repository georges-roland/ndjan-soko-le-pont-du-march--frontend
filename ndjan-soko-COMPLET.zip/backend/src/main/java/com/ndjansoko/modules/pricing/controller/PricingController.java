package com.ndjansoko.modules.pricing.controller;

import com.ndjansoko.modules.pricing.model.MarketPrice;
import com.ndjansoko.modules.harvest.model.ProductType;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Contrôleur Bourse des Prix. RESPONSABLE : R
 * Retourne des prix fictifs de démonstration.
 */
@RestController
@RequestMapping("/api/prices")
@CrossOrigin(origins = "*")
public class PricingController {

    @GetMapping("/today")
    public List<MarketPrice> getTodayPrices() {
        LocalDate today = LocalDate.now();
        return List.of(
            price(ProductType.TOMATO,   "Mfoundi/Sandaga", 275.0, 200.0, 350.0, today),
            price(ProductType.CASSAVA,  "Mokolo",          110.0, 80.0,  150.0, today),
            price(ProductType.PLANTAIN, "Mfoundi",         160.0, 120.0, 200.0, today),
            price(ProductType.AVOCADO,  "Sandaga",         220.0, 150.0, 300.0, today),
            price(ProductType.PEPPER,   "Mokolo",          550.0, 400.0, 700.0, today),
            price(ProductType.MACABO,   "Mfoundi",         130.0, 90.0,  180.0, today)
        );
    }

    private MarketPrice price(ProductType type, String market, double avg, double min, double max, LocalDate date) {
        MarketPrice p = new MarketPrice();
        p.setProductType(type);
        p.setMarketName(market);
        p.setAvgPricePerKgFcfa(avg);
        p.setMinPrice(min);
        p.setMaxPrice(max);
        p.setPriceDate(date);
        return p;
    }
}
