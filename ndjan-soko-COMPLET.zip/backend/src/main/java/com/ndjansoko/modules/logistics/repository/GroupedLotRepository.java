package com.ndjansoko.modules.logistics.repository;

import com.ndjansoko.modules.logistics.model.GroupedLot;
import com.ndjansoko.modules.logistics.model.LotStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repository pour les lots groupés.
 * RESPONSABLE : B
 */
@Repository
public interface GroupedLotRepository extends JpaRepository<GroupedLot, Long> {
    List<GroupedLot> findByStatus(LotStatus status);
    Optional<GroupedLot> findByQrCode(String qrCode);
}
