package com.ndjansoko.modules.harvest.model;

import com.ndjansoko.modules.auth.model.User;
import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "harvests")
public class Harvest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ProductType productType;

    @Column(nullable = false)
    private Double quantityKg;

    @Column(nullable = false)
    private Double pricePerKgFcfa;

    private String variety;
    private Double latitude;
    private Double longitude;
    private String villageName;
    private String region;

    @Enumerated(EnumType.STRING)
    private QualityCategory qualityCategory;

    private Double maturityPercent;
    private String photoPath;

    @Enumerated(EnumType.STRING)
    private HarvestStatus status = HarvestStatus.PENDING_TRANSPORT;

    private LocalDate harvestDate;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private Boolean createdOffline = false;

    // Getters
    public Long getId()                    { return id; }
    public User getFarmer()                { return farmer; }
    public ProductType getProductType()    { return productType; }
    public Double getQuantityKg()          { return quantityKg; }
    public Double getPricePerKgFcfa()      { return pricePerKgFcfa; }
    public String getVariety()             { return variety; }
    public Double getLatitude()            { return latitude; }
    public Double getLongitude()           { return longitude; }
    public String getVillageName()         { return villageName; }
    public String getRegion()              { return region; }
    public QualityCategory getQualityCategory() { return qualityCategory; }
    public Double getMaturityPercent()     { return maturityPercent; }
    public String getPhotoPath()           { return photoPath; }
    public HarvestStatus getStatus()       { return status; }
    public LocalDate getHarvestDate()      { return harvestDate; }
    public LocalDateTime getCreatedAt()    { return createdAt; }
    public Boolean getCreatedOffline()     { return createdOffline; }

    // Setters
    public void setId(Long id)                               { this.id = id; }
    public void setFarmer(User farmer)                       { this.farmer = farmer; }
    public void setProductType(ProductType productType)      { this.productType = productType; }
    public void setQuantityKg(Double quantityKg)             { this.quantityKg = quantityKg; }
    public void setPricePerKgFcfa(Double pricePerKgFcfa)    { this.pricePerKgFcfa = pricePerKgFcfa; }
    public void setVariety(String variety)                   { this.variety = variety; }
    public void setLatitude(Double latitude)                 { this.latitude = latitude; }
    public void setLongitude(Double longitude)               { this.longitude = longitude; }
    public void setVillageName(String villageName)           { this.villageName = villageName; }
    public void setRegion(String region)                     { this.region = region; }
    public void setQualityCategory(QualityCategory q)        { this.qualityCategory = q; }
    public void setMaturityPercent(Double maturityPercent)   { this.maturityPercent = maturityPercent; }
    public void setPhotoPath(String photoPath)               { this.photoPath = photoPath; }
    public void setStatus(HarvestStatus status)              { this.status = status; }
    public void setHarvestDate(LocalDate harvestDate)        { this.harvestDate = harvestDate; }
    public void setCreatedAt(LocalDateTime createdAt)        { this.createdAt = createdAt; }
    public void setCreatedOffline(Boolean createdOffline)    { this.createdOffline = createdOffline; }
}
