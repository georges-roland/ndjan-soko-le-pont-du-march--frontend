package com.ndjansoko.modules.harvest.model;

/**
 * Types de produits agricoles supportés.
 * RESPONSABLE : R
 */
public enum ProductType {
    TOMATO,     // Tomate
    CASSAVA,    // Manioc
    PLANTAIN,   // Plantain
    MACABO,     // Macabo
    AVOCADO,    // Avocat
    PEPPER,     // Piment
    ONION,      // Oignon
    OTHER       // Autre
}
