package com.ndjansoko.modules.ussd.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "ussd_sessions")
public class UssdSession {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String sessionId;

    @Column(nullable = false)
    private String phoneNumber;

    @Column(nullable = false)
    private String currentStep;

    @Column(columnDefinition = "TEXT")
    private String collectedData;

    @Column(nullable = false)
    private LocalDateTime lastActivity = LocalDateTime.now();

    // Getters
    public Long getId()                   { return id; }
    public String getSessionId()          { return sessionId; }
    public String getPhoneNumber()        { return phoneNumber; }
    public String getCurrentStep()        { return currentStep; }
    public String getCollectedData()      { return collectedData; }
    public LocalDateTime getLastActivity(){ return lastActivity; }

    // Setters
    public void setId(Long id)                          { this.id = id; }
    public void setSessionId(String sessionId)          { this.sessionId = sessionId; }
    public void setPhoneNumber(String phoneNumber)      { this.phoneNumber = phoneNumber; }
    public void setCurrentStep(String currentStep)      { this.currentStep = currentStep; }
    public void setCollectedData(String collectedData)  { this.collectedData = collectedData; }
    public void setLastActivity(LocalDateTime v)        { this.lastActivity = v; }

    /** Retourne true si la session a expiré (> 3 minutes d'inactivité). */
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(lastActivity.plusMinutes(3));
    }
}
