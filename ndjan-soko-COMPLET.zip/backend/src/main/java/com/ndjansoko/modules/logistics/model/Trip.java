package com.ndjansoko.modules.logistics.model;

import com.ndjansoko.modules.auth.model.User;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "trips")
public class Trip {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transporter_id", nullable = false)
    private User transporter;

    @Column(nullable = false)
    private String departureCity;

    @Column(nullable = false)
    private String arrivalCity;

    @Column(nullable = false)
    private LocalDateTime departureTime;

    @Column(nullable = false)
    private Double totalCapacityKg;

    @Column(nullable = false)
    private Double availableCapacityKg;

    @Column(nullable = false)
    private Double pricePerKgFcfa;

    @Enumerated(EnumType.STRING)
    private TripStatus status = TripStatus.OPEN;

    @Column(columnDefinition = "TEXT")
    private String routeJson;

    private LocalDateTime createdAt = LocalDateTime.now();

    // Getters
    public Long getId()                      { return id; }
    public User getTransporter()             { return transporter; }
    public String getDepartureCity()         { return departureCity; }
    public String getArrivalCity()           { return arrivalCity; }
    public LocalDateTime getDepartureTime()  { return departureTime; }
    public Double getTotalCapacityKg()       { return totalCapacityKg; }
    public Double getAvailableCapacityKg()   { return availableCapacityKg; }
    public Double getPricePerKgFcfa()        { return pricePerKgFcfa; }
    public TripStatus getStatus()            { return status; }
    public String getRouteJson()             { return routeJson; }
    public LocalDateTime getCreatedAt()      { return createdAt; }

    // Setters
    public void setId(Long id)                               { this.id = id; }
    public void setTransporter(User transporter)             { this.transporter = transporter; }
    public void setDepartureCity(String departureCity)       { this.departureCity = departureCity; }
    public void setArrivalCity(String arrivalCity)           { this.arrivalCity = arrivalCity; }
    public void setDepartureTime(LocalDateTime departureTime){ this.departureTime = departureTime; }
    public void setTotalCapacityKg(Double totalCapacityKg)  { this.totalCapacityKg = totalCapacityKg; }
    public void setAvailableCapacityKg(Double v)            { this.availableCapacityKg = v; }
    public void setPricePerKgFcfa(Double pricePerKgFcfa)    { this.pricePerKgFcfa = pricePerKgFcfa; }
    public void setStatus(TripStatus status)                 { this.status = status; }
    public void setRouteJson(String routeJson)               { this.routeJson = routeJson; }
    public void setCreatedAt(LocalDateTime createdAt)        { this.createdAt = createdAt; }
}
