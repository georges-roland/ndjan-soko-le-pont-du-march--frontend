package com.ndjansoko.modules.payment.model;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.harvest.model.Harvest;
import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class Transaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "buyer_id", nullable = false)
    private User buyer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "farmer_id", nullable = false)
    private User farmer;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "transporter_id")
    private User transporter;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "harvest_id", nullable = false)
    private Harvest harvest;

    @Column(nullable = false)
    private Double totalAmountFcfa;

    private Double farmerShareFcfa;
    private Double transporterShareFcfa;
    private Double platformCommissionFcfa;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status = TransactionStatus.PENDING;

    private String mobileMoneyProvider;
    private String externalTransactionId;

    @Column(length = 64)
    private String previousHash;

    @Column(length = 64)
    private String currentHash;

    private Boolean chainValid = true;

    @Column(nullable = false, updatable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    private LocalDateTime confirmedAt;
    private LocalDateTime releasedAt;

    // Getters
    public Long getId()                           { return id; }
    public User getBuyer()                        { return buyer; }
    public User getFarmer()                       { return farmer; }
    public User getTransporter()                  { return transporter; }
    public Harvest getHarvest()                   { return harvest; }
    public Double getTotalAmountFcfa()            { return totalAmountFcfa; }
    public Double getFarmerShareFcfa()            { return farmerShareFcfa; }
    public Double getTransporterShareFcfa()       { return transporterShareFcfa; }
    public Double getPlatformCommissionFcfa()     { return platformCommissionFcfa; }
    public TransactionStatus getStatus()          { return status; }
    public String getMobileMoneyProvider()        { return mobileMoneyProvider; }
    public String getExternalTransactionId()      { return externalTransactionId; }
    public String getPreviousHash()               { return previousHash; }
    public String getCurrentHash()                { return currentHash; }
    public Boolean getChainValid()                { return chainValid; }
    public LocalDateTime getCreatedAt()           { return createdAt; }
    public LocalDateTime getConfirmedAt()         { return confirmedAt; }
    public LocalDateTime getReleasedAt()          { return releasedAt; }

    // Setters
    public void setId(Long id)                                    { this.id = id; }
    public void setBuyer(User buyer)                              { this.buyer = buyer; }
    public void setFarmer(User farmer)                            { this.farmer = farmer; }
    public void setTransporter(User transporter)                  { this.transporter = transporter; }
    public void setHarvest(Harvest harvest)                       { this.harvest = harvest; }
    public void setTotalAmountFcfa(Double v)                      { this.totalAmountFcfa = v; }
    public void setFarmerShareFcfa(Double v)                      { this.farmerShareFcfa = v; }
    public void setTransporterShareFcfa(Double v)                 { this.transporterShareFcfa = v; }
    public void setPlatformCommissionFcfa(Double v)               { this.platformCommissionFcfa = v; }
    public void setStatus(TransactionStatus status)               { this.status = status; }
    public void setMobileMoneyProvider(String v)                  { this.mobileMoneyProvider = v; }
    public void setExternalTransactionId(String v)                { this.externalTransactionId = v; }
    public void setPreviousHash(String previousHash)              { this.previousHash = previousHash; }
    public void setCurrentHash(String currentHash)                { this.currentHash = currentHash; }
    public void setChainValid(Boolean chainValid)                 { this.chainValid = chainValid; }
    public void setCreatedAt(LocalDateTime createdAt)             { this.createdAt = createdAt; }
    public void setConfirmedAt(LocalDateTime confirmedAt)         { this.confirmedAt = confirmedAt; }
    public void setReleasedAt(LocalDateTime releasedAt)           { this.releasedAt = releasedAt; }
}
