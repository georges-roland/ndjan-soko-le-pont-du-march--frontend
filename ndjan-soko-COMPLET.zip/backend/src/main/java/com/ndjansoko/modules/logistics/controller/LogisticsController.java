package com.ndjansoko.modules.logistics.controller;

import com.ndjansoko.modules.logistics.dto.TripCreateDto;
import com.ndjansoko.modules.logistics.model.GroupedLot;
import com.ndjansoko.modules.logistics.model.Trip;
import com.ndjansoko.modules.logistics.service.LogisticsService;
import com.ndjansoko.modules.auth.model.User;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Contrôleur Logistique. RESPONSABLE : B
 *
 *  POST /api/trips                 → Déclarer un trajet
 *  GET  /api/trips/my              → Mes trajets
 *  GET  /api/logistics/lots        → Lots en attente de camion
 *  POST /api/logistics/group       → Déclencher le groupage manuellement
 *  POST /api/logistics/qr/{code}   → Valider chargement par QR
 */
@RestController
@CrossOrigin(origins = "http://localhost:3000")
public class LogisticsController {

    private final LogisticsService logisticsService;

    public LogisticsController(LogisticsService logisticsService) {
        this.logisticsService = logisticsService;
    }

    @PostMapping("/api/trips")
    public ResponseEntity<Trip> createTrip(
            @Valid @RequestBody TripCreateDto dto,
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(logisticsService.createTrip(dto, user.getId()));
    }

    @GetMapping("/api/trips/my")
    public ResponseEntity<List<Trip>> getMyTrips(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(logisticsService.getMyTrips(user.getId()));
    }

    @GetMapping("/api/logistics/lots")
    public ResponseEntity<List<GroupedLot>> getPendingLots() {
        return ResponseEntity.ok(logisticsService.getPendingLots());
    }

    @PostMapping("/api/logistics/group")
    public ResponseEntity<String> runGrouping() {
        logisticsService.runGroupingAlgorithm();
        return ResponseEntity.ok("Algorithme de groupage exécuté avec succès");
    }

    @PostMapping("/api/logistics/qr/{qrCode}")
    public ResponseEntity<String> validateLoading(
            @PathVariable String qrCode,
            @AuthenticationPrincipal User user) {
        logisticsService.validateLoadingByQrCode(qrCode, user.getId());
        return ResponseEntity.ok("Chargement validé — Marchandises en transit ✅");
    }
}
