package com.ndjansoko.modules.ussd.service;

import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.model.HarvestStatus;
import com.ndjansoko.modules.harvest.model.ProductType;
import com.ndjansoko.modules.harvest.model.QualityCategory;
import com.ndjansoko.modules.harvest.repository.HarvestRepository;
import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.repository.UserRepository;
import com.ndjansoko.modules.ussd.model.UssdSession;
import com.ndjansoko.modules.ussd.repository.UssdSessionRepository;
import com.ndjansoko.modules.payment.repository.TransactionRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.logging.Logger;

/**
 * Service USSD — Machine à états pour téléphones basiques. RESPONSABLE : A
 *
 * Format des réponses :
 *   CON ... → continue (affiche menu, attend réponse)
 *   END ... → termine la session
 *
 * Le paramètre 'text' accumule toutes les saisies séparées par '*'
 *   ex: "1*2*50" = l'utilisateur a saisi 1, puis 2, puis 50
 */
@Service
public class UssdService {

    private static final Logger LOGGER = Logger.getLogger(UssdService.class.getName());

    private final UssdSessionRepository sessionRepository;
    private final HarvestRepository     harvestRepository;
    private final UserRepository        userRepository;
    private final TransactionRepository transactionRepository;

    public UssdService(UssdSessionRepository sessionRepository,
                       HarvestRepository harvestRepository,
                       UserRepository userRepository,
                       TransactionRepository transactionRepository) {
        this.sessionRepository    = sessionRepository;
        this.harvestRepository    = harvestRepository;
        this.userRepository       = userRepository;
        this.transactionRepository = transactionRepository;
    }

    // ─── Point d'entrée principal ─────────────────────────────────────────────

    @Transactional
    public String processUssdRequest(String sessionId, String phoneNumber, String text) {
        // Récupérer ou créer la session
        UssdSession session = sessionRepository.findBySessionId(sessionId)
                .orElseGet(() -> createSession(sessionId, phoneNumber));

        // Session expirée → repartir du début
        if (session.isExpired() && !text.isEmpty()) {
            session.setCurrentStep("START");
            session.setCollectedData("");
        }

        session.setLastActivity(LocalDateTime.now());

        // Décomposer le texte en étapes (ex: "1*2*50" → ["1","2","50"])
        String[] inputs = text.isEmpty() ? new String[]{} : text.split("\\*");
        String lastInput = inputs.length > 0 ? inputs[inputs.length - 1].trim() : "";

        String response = route(session, inputs, lastInput, phoneNumber);

        sessionRepository.save(session);
        return response;
    }

    // ─── Machine à états ─────────────────────────────────────────────────────

    private String route(UssdSession session, String[] inputs, String lastInput, String phone) {
        int depth = inputs.length;

        // Niveau 0 : Menu principal
        if (depth == 0) {
            session.setCurrentStep("MAIN_MENU");
            return menuPrincipal();
        }

        String first = inputs[0];

        // ── Option 1 : Enregistrer une récolte ──
        if ("1".equals(first)) {
            if (depth == 1) {
                session.setCurrentStep("SELECT_PRODUCT");
                return "CON Choisissez le produit :\n1. Tomate\n2. Manioc\n3. Plantain\n4. Avocat\n5. Piment";
            }
            if (depth == 2) {
                session.setCurrentStep("ENTER_QUANTITY");
                String product = productName(inputs[1]);
                return "CON " + product + " sélectionné.\nEntrez la quantité (en kg) :";
            }
            if (depth == 3) {
                session.setCurrentStep("ENTER_PRICE");
                return "CON Entrez votre prix (FCFA par kg) :";
            }
            if (depth == 4) {
                // Toutes les données collectées → créer l'annonce
                return createHarvestFromUssd(phone, inputs[1], inputs[2], inputs[3]);
            }
        }

        // ── Option 2 : Prix du marché ──
        if ("2".equals(first)) {
            session.setCurrentStep("MARKET_PRICES");
            return buildPricesMenu();
        }

        // ── Option 3 : Mon solde séquestre ──
        if ("3".equals(first)) {
            return buildBalanceMenu(phone);
        }

        // ── Option invalide ──
        session.setCurrentStep("MAIN_MENU");
        return "CON Option invalide. Réessayez :\n" + menuPrincipal().replace("CON ", "");
    }

    // ─── Constructeurs de menus ───────────────────────────────────────────────

    private String menuPrincipal() {
        return "CON Ndjan-Soko - Le Pont du Marché\n" +
               "1. Enregistrer une récolte\n" +
               "2. Prix du marché aujourd'hui\n" +
               "3. Mon solde séquestre";
    }

    private String buildPricesMenu() {
        return "END Prix du jour (FCFA/kg) :\n" +
               "Tomate   : 200 - 350\n" +
               "Manioc   : 80  - 150\n" +
               "Plantain : 120 - 200\n" +
               "Avocat   : 150 - 300\n" +
               "Piment   : 400 - 700\n" +
               "(Source : Marchés Mfoundi & Sandaga)";
    }

    private String buildBalanceMenu(String phone) {
        long count = transactionRepository.findByFarmerIdOrderByIdAsc(
                userRepository.findByPhoneNumber(phone)
                              .map(u -> u.getId()).orElse(0L)
        ).stream().filter(t -> "ESCROWED".equals(t.getStatus().name())).count();

        return "END Votre compte Ndjan-Soko :\n" +
               "Transactions en séquestre : " + count + "\n" +
               "Pour plus de détails,\nconnectez-vous sur l'application.";
    }

    // ─── Création de récolte depuis USSD ─────────────────────────────────────

    private String createHarvestFromUssd(String phone, String productCode, String qtyStr, String priceStr) {
        try {
            User user = userRepository.findByPhoneNumber(phone).orElse(null);
            if (user == null) {
                return "END Numéro non enregistré.\nInscrivez-vous d'abord sur l'application Ndjan-Soko.";
            }

            double qty   = Double.parseDouble(qtyStr.trim());
            double price = Double.parseDouble(priceStr.trim());

            if (qty <= 0 || price <= 0) {
                return "END Quantité ou prix invalide.\nRecommencez avec des valeurs positives.";
            }

            Harvest harvest = new Harvest();
            harvest.setFarmer(user);
            harvest.setProductType(productTypeFromCode(productCode));
            harvest.setQuantityKg(qty);
            harvest.setPricePerKgFcfa(price);
            harvest.setHarvestDate(LocalDate.now());
            harvest.setStatus(HarvestStatus.PENDING_TRANSPORT);
            harvest.setQualityCategory(QualityCategory.CAT_B); // défaut USSD
            harvest.setCreatedOffline(false);
            harvest.setVillageName("Via USSD");

            harvestRepository.save(harvest);

            LOGGER.info("📱 Récolte USSD créée : " + qty + "kg de " + harvest.getProductType() + " pour " + phone);

            return "END Annonce publiée !\n" +
                   productName(productCode) + " - " + (int)qty + " kg\n" +
                   "Prix : " + (int)price + " FCFA/kg\n" +
                   "Visible sur Ndjan-Soko maintenant.";

        } catch (NumberFormatException e) {
            return "END Erreur : entrez des chiffres valides pour la quantité et le prix.";
        }
    }

    // ─── Utilitaires ─────────────────────────────────────────────────────────

    private UssdSession createSession(String sessionId, String phoneNumber) {
        UssdSession s = new UssdSession();
        s.setSessionId(sessionId);
        s.setPhoneNumber(phoneNumber);
        s.setCurrentStep("START");
        s.setCollectedData("");
        s.setLastActivity(LocalDateTime.now());
        return sessionRepository.save(s);
    }

    private String productName(String code) {
        return switch (code) {
            case "1" -> "Tomate";
            case "2" -> "Manioc";
            case "3" -> "Plantain";
            case "4" -> "Avocat";
            case "5" -> "Piment";
            default  -> "Autre";
        };
    }

    private ProductType productTypeFromCode(String code) {
        return switch (code) {
            case "1" -> ProductType.TOMATO;
            case "2" -> ProductType.CASSAVA;
            case "3" -> ProductType.PLANTAIN;
            case "4" -> ProductType.AVOCADO;
            case "5" -> ProductType.PEPPER;
            default  -> ProductType.OTHER;
        };
    }

    /** Nettoyage automatique des sessions expirées toutes les 5 minutes. */
    @Scheduled(fixedRate = 300_000)
    public void cleanExpiredSessions() {
        List<UssdSession> all = sessionRepository.findAll();
        long deleted = all.stream().filter(UssdSession::isExpired).peek(s -> sessionRepository.delete(s)).count();
        if (deleted > 0) LOGGER.info("🧹 " + deleted + " session(s) USSD expirée(s) supprimée(s)");
    }
}
