package com.ndjansoko.modules.payment.controller;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.service.LedgerService;
import com.ndjansoko.modules.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/**
 * Contrôleur Paiement. RESPONSABLE : D
 *
 *  POST /api/payments/escrow         → Initier le paiement
 *  POST /api/payments/{id}/confirm   → Confirmer la réception
 *  GET  /api/payments/verify-chain   → Vérifier intégrité SHA-256 (admin/démo)
 */
@RestController
@RequestMapping("/api/payments")
@CrossOrigin(origins = "http://localhost:3000")
public class PaymentController {

    private final PaymentService paymentService;
    private final LedgerService  ledgerService;

    public PaymentController(PaymentService paymentService, LedgerService ledgerService) {
        this.paymentService = paymentService;
        this.ledgerService  = ledgerService;
    }

    @PostMapping("/escrow")
    public ResponseEntity<Transaction> initiateEscrow(
            @RequestParam Long harvestId,
            @RequestParam String provider,
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(paymentService.initiateEscrow(user.getId(), harvestId, provider));
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<Transaction> confirmReceipt(
            @PathVariable Long id,
            @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(paymentService.releaseEscrow(id, user.getId()));
    }

    @GetMapping("/verify-chain")
    public ResponseEntity<String> verifyChain() {
        boolean valid = ledgerService.verifyChain();
        String msg = valid
                ? "✅ Registre intègre — Aucune fraude détectée sur la chaîne SHA-256"
                : "🚨 ALERTE FRAUDE — La chaîne SHA-256 est corrompue ! Contactez l'administrateur.";
        return ResponseEntity.ok(msg);
    }
}
