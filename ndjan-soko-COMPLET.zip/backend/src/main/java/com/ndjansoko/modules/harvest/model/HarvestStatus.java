package com.ndjansoko.modules.harvest.model;

/**
 * Statuts du cycle de vie d'une récolte.
 * RESPONSABLE : R
 */
public enum HarvestStatus {
    PENDING_TRANSPORT,  // Annonce publiée, cherche un camion
    GROUPED,            // Groupage logistique validé
    IN_TRANSIT,         // En chemin vers la ville
    DELIVERED,          // Livré à l'acheteur
    AT_HUB,             // Déposé au hub physique
    CANCELLED           // Annulé
}
