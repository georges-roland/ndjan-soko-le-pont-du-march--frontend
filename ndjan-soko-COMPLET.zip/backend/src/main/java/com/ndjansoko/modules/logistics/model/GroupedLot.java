package com.ndjansoko.modules.logistics.model;

import com.ndjansoko.modules.harvest.model.Harvest;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "grouped_lots")
public class GroupedLot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToMany
    @JoinTable(name = "lot_harvests",
        joinColumns = @JoinColumn(name = "lot_id"),
        inverseJoinColumns = @JoinColumn(name = "harvest_id"))
    private List<Harvest> harvests;

    @ManyToOne
    @JoinColumn(name = "trip_id")
    private Trip assignedTrip;

    private Double totalQuantityKg;
    private Double centerLatitude;
    private Double centerLongitude;
    private String region;

    @Enumerated(EnumType.STRING)
    private LotStatus status = LotStatus.PENDING_TRUCK;

    private LocalDateTime createdAt = LocalDateTime.now();
    private String qrCode;

    @PrePersist
    public void generateQrCode() {
        if (this.qrCode == null) {
            this.qrCode = "NDJANSOKO-LOT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        }
    }

    // Getters
    public Long getId()                    { return id; }
    public List<Harvest> getHarvests()     { return harvests; }
    public Trip getAssignedTrip()          { return assignedTrip; }
    public Double getTotalQuantityKg()     { return totalQuantityKg; }
    public Double getCenterLatitude()      { return centerLatitude; }
    public Double getCenterLongitude()     { return centerLongitude; }
    public String getRegion()              { return region; }
    public LotStatus getStatus()           { return status; }
    public LocalDateTime getCreatedAt()    { return createdAt; }
    public String getQrCode()              { return qrCode; }

    // Setters
    public void setId(Long id)                         { this.id = id; }
    public void setHarvests(List<Harvest> harvests)    { this.harvests = harvests; }
    public void setAssignedTrip(Trip assignedTrip)     { this.assignedTrip = assignedTrip; }
    public void setTotalQuantityKg(Double v)           { this.totalQuantityKg = v; }
    public void setCenterLatitude(Double centerLatitude){ this.centerLatitude = centerLatitude; }
    public void setCenterLongitude(Double centerLongitude){ this.centerLongitude = centerLongitude; }
    public void setRegion(String region)               { this.region = region; }
    public void setStatus(LotStatus status)            { this.status = status; }
    public void setCreatedAt(LocalDateTime createdAt)  { this.createdAt = createdAt; }
    public void setQrCode(String qrCode)               { this.qrCode = qrCode; }
}
