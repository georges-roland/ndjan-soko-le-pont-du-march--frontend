package com.ndjansoko.modules.auth.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/**
 * DTO pour la vérification du code OTP. RESPONSABLE : F
 */
public class OtpVerifyDto {

    @NotBlank
    private String phoneNumber;

    @NotBlank
    @Pattern(regexp = "^[0-9]{6}$", message = "Le code OTP doit être 6 chiffres")
    private String code;

    private String role;

    public String getPhoneNumber()       { return phoneNumber; }
    public void setPhoneNumber(String p) { this.phoneNumber = p; }

    public String getCode()              { return code; }
    public void setCode(String c)        { this.code = c; }

    public String getRole()              { return role; }
    public void setRole(String r)        { this.role = r; }
}
