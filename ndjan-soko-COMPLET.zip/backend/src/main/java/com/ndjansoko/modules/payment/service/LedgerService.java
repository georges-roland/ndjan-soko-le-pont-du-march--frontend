package com.ndjansoko.modules.payment.service;

import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.repository.TransactionRepository;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.List;
import java.util.Optional;
import java.util.logging.Logger;

/**
 * Registre Financier Immuable — chaîne de hachage SHA-256 anti-fraude.
 * RESPONSABLE : D
 *
 * Principe :
 *   Chaque transaction contient le hash SHA-256 de la précédente.
 *   Toute modification frauduleuse en base brise la chaîne → alerte levée.
 */
@Service
public class LedgerService {

    private static final Logger LOGGER = Logger.getLogger(LedgerService.class.getName());
    private static final String GENESIS_HASH = "0000000000000000000000000000000000000000000000000000000000000000";

    private final TransactionRepository transactionRepository;

    public LedgerService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    // ─── 1. SHA-256 utilitaire ────────────────────────────────────────────────

    /**
     * Calcule le SHA-256 d'une chaîne de caractères et retourne le résultat en hexadécimal.
     */
    public String sha256(String input) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = digest.digest(input.getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hashBytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 indisponible sur cette JVM", e);
        }
    }

    // ─── 2. Calcul du hash d'une transaction ─────────────────────────────────

    /**
     * Concatène les champs clés de la transaction et calcule son SHA-256.
     * Si un champ est modifié en base, ce hash ne correspondra plus.
     */
    public String computeHash(Transaction tx) {
        String raw = String.join("|",
                String.valueOf(tx.getId()),
                String.valueOf(tx.getTotalAmountFcfa()),
                tx.getBuyer()  != null ? String.valueOf(tx.getBuyer().getId())   : "null",
                tx.getFarmer() != null ? String.valueOf(tx.getFarmer().getId())  : "null",
                String.valueOf(tx.getStatus()),
                tx.getPreviousHash() != null ? tx.getPreviousHash() : GENESIS_HASH,
                tx.getCreatedAt() != null ? tx.getCreatedAt().toString() : "null"
        );
        return sha256(raw);
    }

    // ─── 3. Attacher le hash avant sauvegarde ────────────────────────────────

    /**
     * Récupère le hash de la dernière transaction, le définit comme previousHash
     * de la nouvelle transaction, calcule son currentHash, puis sauvegarde.
     */
    public Transaction attachHash(Transaction tx) {
        // Récupérer le hash de la dernière transaction (ou hash genesis si première)
        String prevHash = transactionRepository
                .findTopByOrderByIdDesc()
                .map(Transaction::getCurrentHash)
                .orElse(GENESIS_HASH);

        tx.setPreviousHash(prevHash);
        tx.setCurrentHash(computeHash(tx));

        return transactionRepository.save(tx);
    }

    // ─── 4. Vérification de l'intégrité de toute la chaîne ───────────────────

    /**
     * Parcourt toutes les transactions dans l'ordre et vérifie que chaque
     * previousHash correspond bien au currentHash de la précédente.
     *
     * @return true si la chaîne est intègre, false si une fraude est détectée
     */
    public boolean verifyChain() {
        List<Transaction> all = transactionRepository.findAll()
                .stream()
                .sorted((a, b) -> Long.compare(a.getId(), b.getId()))
                .toList();

        if (all.isEmpty()) return true;

        String expectedPrevious = GENESIS_HASH;

        for (Transaction tx : all) {
            // Vérifier que le previousHash est correct
            if (!expectedPrevious.equals(tx.getPreviousHash())) {
                LOGGER.severe("🚨 FRAUDE DÉTECTÉE sur transaction id=" + tx.getId()
                        + " | previousHash attendu=" + expectedPrevious
                        + " | trouvé=" + tx.getPreviousHash());
                tx.setChainValid(false);
                transactionRepository.save(tx);
                return false;
            }

            // Recalculer le hash et comparer
            String recomputed = computeHash(tx);
            if (!recomputed.equals(tx.getCurrentHash())) {
                LOGGER.severe("🚨 HASH CORROMPU sur transaction id=" + tx.getId()
                        + " | hash attendu=" + recomputed
                        + " | trouvé=" + tx.getCurrentHash());
                tx.setChainValid(false);
                transactionRepository.save(tx);
                return false;
            }

            expectedPrevious = tx.getCurrentHash();
        }

        LOGGER.info("✅ Chaîne de " + all.size() + " transaction(s) vérifiée — aucune fraude");
        return true;
    }
}
