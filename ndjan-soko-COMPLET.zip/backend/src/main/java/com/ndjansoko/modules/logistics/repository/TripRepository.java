package com.ndjansoko.modules.logistics.repository;

import com.ndjansoko.modules.logistics.model.Trip;
import com.ndjansoko.modules.logistics.model.TripStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

/**
 * Repository pour les trajets.
 * RESPONSABLE : B
 */
@Repository
public interface TripRepository extends JpaRepository<Trip, Long> {
    List<Trip> findByStatusAndAvailableCapacityKgGreaterThanEqual(TripStatus status, Double minCapacity);
    List<Trip> findByTransporterId(Long transporterId);
}
