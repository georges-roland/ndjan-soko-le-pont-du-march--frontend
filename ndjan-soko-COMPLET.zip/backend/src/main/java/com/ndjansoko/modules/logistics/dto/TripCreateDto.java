package com.ndjansoko.modules.logistics.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDateTime;

/**
 * DTO pour déclarer un trajet. RESPONSABLE : B
 */
public class TripCreateDto {

    @NotBlank(message = "La ville de départ est obligatoire")
    private String departureCity;

    @NotBlank(message = "La ville d'arrivée est obligatoire")
    private String arrivalCity;

    @NotNull(message = "La date de départ est obligatoire")
    private LocalDateTime departureTime;

    @NotNull @Positive
    private Double totalCapacityKg;

    @NotNull @Positive
    private Double availableCapacityKg;

    @NotNull @Positive
    private Double pricePerKgFcfa;

    public String getDepartureCity()              { return departureCity; }
    public void setDepartureCity(String v)        { this.departureCity = v; }
    public String getArrivalCity()                { return arrivalCity; }
    public void setArrivalCity(String v)          { this.arrivalCity = v; }
    public LocalDateTime getDepartureTime()       { return departureTime; }
    public void setDepartureTime(LocalDateTime v) { this.departureTime = v; }
    public Double getTotalCapacityKg()            { return totalCapacityKg; }
    public void setTotalCapacityKg(Double v)      { this.totalCapacityKg = v; }
    public Double getAvailableCapacityKg()        { return availableCapacityKg; }
    public void setAvailableCapacityKg(Double v)  { this.availableCapacityKg = v; }
    public Double getPricePerKgFcfa()             { return pricePerKgFcfa; }
    public void setPricePerKgFcfa(Double v)       { this.pricePerKgFcfa = v; }
}
