package com.ndjansoko.modules.logistics.service;

import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.model.HarvestStatus;
import com.ndjansoko.modules.harvest.model.ProductType;
import com.ndjansoko.modules.harvest.repository.HarvestRepository;
import com.ndjansoko.modules.logistics.dto.TripCreateDto;
import com.ndjansoko.modules.logistics.model.*;
import com.ndjansoko.modules.logistics.repository.*;
import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/**
 * Service logistique — Algorithme de groupage. RESPONSABLE : B
 */
@Service
public class LogisticsService {

    private static final Logger LOGGER = Logger.getLogger(LogisticsService.class.getName());
    private static final double GROUPING_RADIUS   = 0.15;  // ~15 km en degrés
    private static final double MIN_GROUP_QTY_KG  = 500.0; // seuil de groupage
    private static final int    MIN_FARMERS        = 2;     // min agriculteurs pour grouper

    private final HarvestRepository     harvestRepository;
    private final GroupedLotRepository  groupedLotRepository;
    private final TripRepository        tripRepository;
    private final UserRepository        userRepository;

    public LogisticsService(HarvestRepository harvestRepository,
                            GroupedLotRepository groupedLotRepository,
                            TripRepository tripRepository,
                            UserRepository userRepository) {
        this.harvestRepository    = harvestRepository;
        this.groupedLotRepository = groupedLotRepository;
        this.tripRepository       = tripRepository;
        this.userRepository       = userRepository;
    }

    // ─── 1. Algorithme de groupage ────────────────────────────────────────────

    @Transactional
    public void runGroupingAlgorithm() {
        LOGGER.info("🔄 Lancement de l'algorithme de groupage...");
        int lotsCreated = 0;

        for (ProductType productType : ProductType.values()) {
            // Récupérer toutes les récoltes en attente de transport pour ce produit
            List<Harvest> pending = harvestRepository
                    .findByProductTypeAndStatusOrderByCreatedAtDesc(productType, HarvestStatus.PENDING_TRANSPORT);

            if (pending.size() < MIN_FARMERS) continue;

            // Parcourir chaque récolte comme centre potentiel d'un groupe
            List<Harvest> alreadyGrouped = new ArrayList<>();

            for (Harvest center : pending) {
                if (alreadyGrouped.contains(center)) continue;
                if (center.getLatitude() == null || center.getLongitude() == null) continue;

                // Trouver les récoltes voisines dans le rayon
                List<Harvest> nearby = harvestRepository.findNearbyByProduct(
                        productType,
                        center.getLatitude(),
                        center.getLongitude(),
                        GROUPING_RADIUS
                );

                // Exclure celles déjà traitées
                nearby.removeAll(alreadyGrouped);

                if (nearby.size() < MIN_FARMERS) continue;

                // Calculer la quantité totale
                double totalQty = nearby.stream()
                        .mapToDouble(Harvest::getQuantityKg)
                        .sum();

                if (totalQty < MIN_GROUP_QTY_KG) continue;

                // Calculer le centre géographique
                double avgLat = nearby.stream().mapToDouble(Harvest::getLatitude).average().orElse(0);
                double avgLng = nearby.stream().mapToDouble(Harvest::getLongitude).average().orElse(0);

                // Créer le lot groupé
                GroupedLot lot = new GroupedLot();
                lot.setHarvests(new ArrayList<>(nearby));
                lot.setTotalQuantityKg(totalQty);
                lot.setCenterLatitude(avgLat);
                lot.setCenterLongitude(avgLng);
                lot.setRegion(center.getRegion());
                lot.setStatus(LotStatus.PENDING_TRUCK);
                groupedLotRepository.save(lot);

                // Mettre à jour le statut des récoltes groupées
                for (Harvest h : nearby) {
                    h.setStatus(HarvestStatus.GROUPED);
                    harvestRepository.save(h);
                    alreadyGrouped.add(h);
                }

                lotsCreated++;
                LOGGER.info("✅ Lot créé : " + nearby.size() + " agriculteurs, " + totalQty + " kg de " + productType);

                // Tenter immédiatement de matcher un camion
                matchTripToLot(lot.getId());
            }
        }

        LOGGER.info("🏁 Groupage terminé : " + lotsCreated + " lot(s) créé(s)");
    }

    // ─── 2. Matching camion ↔ lot ─────────────────────────────────────────────

    @Transactional
    public void matchTripToLot(Long lotId) {
        GroupedLot lot = groupedLotRepository.findById(lotId)
                .orElseThrow(() -> new IllegalArgumentException("Lot introuvable : " + lotId));

        if (lot.getStatus() != LotStatus.PENDING_TRUCK) return;

        // Chercher un camion OPEN avec assez de capacité
        List<Trip> candidates = tripRepository
                .findByStatusAndAvailableCapacityKgGreaterThanEqual(TripStatus.OPEN, lot.getTotalQuantityKg());

        if (candidates.isEmpty()) {
            LOGGER.info("⚠️ Aucun camion disponible pour le lot " + lotId + " — routage vers hub");
            routeToNearestHub(lotId);
            return;
        }

        // Prendre le premier camion disponible (amélioration possible : trier par distance)
        Trip trip = candidates.get(0);
        trip.setAvailableCapacityKg(trip.getAvailableCapacityKg() - lot.getTotalQuantityKg());
        if (trip.getAvailableCapacityKg() <= 0) trip.setStatus(TripStatus.FULL);
        tripRepository.save(trip);

        lot.setAssignedTrip(trip);
        lot.setStatus(LotStatus.TRUCK_ASSIGNED);
        groupedLotRepository.save(lot);

        LOGGER.info("🚚 Camion " + trip.getId() + " assigné au lot " + lotId);
    }

    // ─── 3. Validation chargement par QR Code ────────────────────────────────

    @Transactional
    public void validateLoadingByQrCode(String qrCode, Long transporterId) {
        GroupedLot lot = groupedLotRepository.findByQrCode(qrCode)
                .orElseThrow(() -> new IllegalArgumentException("QR Code invalide : " + qrCode));

        if (lot.getStatus() != LotStatus.TRUCK_ASSIGNED) {
            throw new IllegalStateException("Ce lot n'est pas prêt au chargement. Statut : " + lot.getStatus());
        }

        // Vérifier que c'est bien le bon chauffeur
        if (lot.getAssignedTrip() != null
                && !lot.getAssignedTrip().getTransporter().getId().equals(transporterId)) {
            throw new IllegalStateException("Ce lot n'est pas assigné à votre camion.");
        }

        lot.setStatus(LotStatus.LOADED);
        groupedLotRepository.save(lot);

        // Mettre les récoltes en transit
        for (Harvest h : lot.getHarvests()) {
            h.setStatus(HarvestStatus.IN_TRANSIT);
            harvestRepository.save(h);
        }

        LOGGER.info("📦 Chargement validé — QR: " + qrCode);
    }

    // ─── 4. Routage vers hub ──────────────────────────────────────────────────

    @Transactional
    public void routeToNearestHub(Long lotId) {
        GroupedLot lot = groupedLotRepository.findById(lotId)
                .orElseThrow(() -> new IllegalArgumentException("Lot introuvable : " + lotId));

        lot.setStatus(LotStatus.AT_HUB);
        groupedLotRepository.save(lot);

        for (Harvest h : lot.getHarvests()) {
            h.setStatus(HarvestStatus.AT_HUB);
            harvestRepository.save(h);
        }

        LOGGER.info("🏪 Lot " + lotId + " routé vers le hub le plus proche");
    }

    // ─── 5. Créer un trajet (transporteur) ───────────────────────────────────

    @Transactional
    public Trip createTrip(TripCreateDto dto, Long transporterId) {
        User transporter = userRepository.findById(transporterId)
                .orElseThrow(() -> new IllegalArgumentException("Transporteur introuvable"));

        Trip trip = new Trip();
        trip.setTransporter(transporter);
        trip.setDepartureCity(dto.getDepartureCity());
        trip.setArrivalCity(dto.getArrivalCity());
        trip.setDepartureTime(dto.getDepartureTime());
        trip.setTotalCapacityKg(dto.getTotalCapacityKg());
        trip.setAvailableCapacityKg(dto.getAvailableCapacityKg());
        trip.setPricePerKgFcfa(dto.getPricePerKgFcfa());
        trip.setStatus(TripStatus.OPEN);

        Trip saved = tripRepository.save(trip);

        // Lancer le matching immédiatement après la déclaration
        runGroupingAlgorithm();

        return saved;
    }

    // ─── 6. Mes trajets ───────────────────────────────────────────────────────

    public List<Trip> getMyTrips(Long transporterId) {
        return tripRepository.findByTransporterId(transporterId);
    }

    // ─── 7. Lots disponibles ──────────────────────────────────────────────────

    public List<GroupedLot> getPendingLots() {
        return groupedLotRepository.findByStatus(LotStatus.PENDING_TRUCK);
    }
}
