package com.ndjansoko.modules.payment.repository;

import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.model.TransactionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repository pour les transactions.
 * RESPONSABLE : D
 */
@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    Optional<Transaction> findTopByOrderByIdDesc(); // Pour la chaîne de hash
    List<Transaction> findByBuyerIdOrderByIdAsc(Long buyerId);
    List<Transaction> findByFarmerIdOrderByIdAsc(Long farmerId);
    List<Transaction> findByChainValidFalse(); // Transactions corrompues (fraude)
    List<Transaction> findByStatus(TransactionStatus status);
}
