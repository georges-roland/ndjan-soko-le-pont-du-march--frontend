package com.ndjansoko.modules.auth.model;

/**
 * Rôles disponibles dans l'application Ndjan-Soko.
 * RESPONSABLE : F
 */
public enum UserRole {
    FARMER,        // Agriculteur / GIC
    BUYER,         // Bayam-Sellam / Grossiste / Supermarché
    TRANSPORTER,   // Chauffeur de camion
    HUB_MANAGER    // Gérant de hub physique
}
