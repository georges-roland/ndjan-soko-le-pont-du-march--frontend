package com.ndjansoko.modules.ussd.controller;

import com.ndjansoko.modules.ussd.service.UssdService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ussd")
@CrossOrigin(origins = "*")
public class UssdController {

    private final UssdService ussdService;

    public UssdController(UssdService ussdService) {
        this.ussdService = ussdService;
    }

    @PostMapping(produces = MediaType.TEXT_PLAIN_VALUE)
    public String handleUssd(@RequestParam String sessionId,
                              @RequestParam String phoneNumber,
                              @RequestParam(defaultValue = "") String text) {
        return ussdService.processUssdRequest(sessionId, phoneNumber, text);
    }
}
