package com.ndjansoko.modules.harvest.controller;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.service.HarvestService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/harvests")
@CrossOrigin(origins = "http://localhost:3000")
public class HarvestController {

    private final HarvestService harvestService;

    public HarvestController(HarvestService harvestService) {
        this.harvestService = harvestService;
    }

    @PostMapping
    public ResponseEntity<Harvest> createHarvest(@Valid @RequestBody HarvestCreateDto dto,
                                                  @AuthenticationPrincipal User user) {
        return ResponseEntity.ok(harvestService.createHarvest(dto, user.getId()));
    }

    @GetMapping("/my")
    public ResponseEntity<List<Harvest>> getMyHarvests(@AuthenticationPrincipal User user) {
        return ResponseEntity.ok(harvestService.getFarmerHarvests(user.getId()));
    }

    @GetMapping
    public ResponseEntity<List<Harvest>> getAvailableHarvests(
            @RequestParam(required = false) String productType,
            @RequestParam(required = false) String region,
            @RequestParam(required = false) Double minQuantity) {
        return ResponseEntity.ok(harvestService.getAvailableHarvests(productType, region, minQuantity));
    }

    @GetMapping("/suggest-price")
    public ResponseEntity<Double> suggestPrice(@RequestParam String qualityCategory,
                                                @RequestParam String productType) {
        return ResponseEntity.ok(harvestService.suggestPrice(qualityCategory, productType));
    }
}
