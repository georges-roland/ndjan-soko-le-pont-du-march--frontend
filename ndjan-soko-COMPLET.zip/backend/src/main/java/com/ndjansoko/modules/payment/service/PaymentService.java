package com.ndjansoko.modules.payment.service;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.repository.UserRepository;
import com.ndjansoko.modules.harvest.model.Harvest;
import com.ndjansoko.modules.harvest.model.HarvestStatus;
import com.ndjansoko.modules.harvest.repository.HarvestRepository;
import com.ndjansoko.modules.payment.model.Transaction;
import com.ndjansoko.modules.payment.model.TransactionStatus;
import com.ndjansoko.modules.payment.repository.TransactionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.logging.Logger;

/**
 * Service de séquestre (Escrow) et paiements Mobile Money. RESPONSABLE : D
 */
@Service
public class PaymentService {

    private static final Logger LOGGER = Logger.getLogger(PaymentService.class.getName());
    private static final double PLATFORM_RATE    = 0.04;  // 4% de commission
    private static final double FARMER_RATE      = 0.80;  // 80% du net pour l'agriculteur
    private static final double TRANSPORTER_RATE = 0.20;  // 20% du net pour le transporteur

    private final TransactionRepository transactionRepository;
    private final HarvestRepository     harvestRepository;
    private final UserRepository        userRepository;
    private final LedgerService         ledgerService;

    public PaymentService(TransactionRepository transactionRepository,
                          HarvestRepository harvestRepository,
                          UserRepository userRepository,
                          LedgerService ledgerService) {
        this.transactionRepository = transactionRepository;
        this.harvestRepository     = harvestRepository;
        this.userRepository        = userRepository;
        this.ledgerService         = ledgerService;
    }

    // ─── 1. Initier l'Escrow ─────────────────────────────────────────────────

    @Transactional
    public Transaction initiateEscrow(Long buyerId, Long harvestId, String mobileMoneyProvider) {
        User buyer = userRepository.findById(buyerId)
                .orElseThrow(() -> new IllegalArgumentException("Acheteur introuvable"));

        Harvest harvest = harvestRepository.findById(harvestId)
                .orElseThrow(() -> new IllegalArgumentException("Récolte introuvable"));

        if (harvest.getStatus() == HarvestStatus.DELIVERED) {
            throw new IllegalStateException("Cette récolte est déjà vendue.");
        }

        // Calculer le montant total (marchandise + transport estimé)
        double total = harvest.getQuantityKg() * harvest.getPricePerKgFcfa();

        // Répartition financière
        double commission    = total * PLATFORM_RATE;
        double net           = total - commission;
        double farmerShare   = net * FARMER_RATE;
        double transportShare= net * TRANSPORTER_RATE;

        // Construire la transaction
        Transaction tx = new Transaction();
        tx.setBuyer(buyer);
        tx.setFarmer(harvest.getFarmer());
        tx.setHarvest(harvest);
        tx.setTotalAmountFcfa(total);
        tx.setPlatformCommissionFcfa(commission);
        tx.setFarmerShareFcfa(farmerShare);
        tx.setTransporterShareFcfa(transportShare);
        tx.setStatus(TransactionStatus.PENDING);
        tx.setMobileMoneyProvider(mobileMoneyProvider);
        tx.setCreatedAt(LocalDateTime.now());

        // Simuler le débit Mobile Money
        String extId = simulateMobileMoneyPayment(buyer.getPhoneNumber(), total, mobileMoneyProvider);
        tx.setExternalTransactionId(extId);
        tx.setStatus(TransactionStatus.ESCROWED);

        // Attacher le hash SHA-256 et sauvegarder dans le registre immuable
        Transaction saved = ledgerService.attachHash(tx);

        LOGGER.info("🔐 Escrow créé — " + total + " FCFA gelés | tx#" + saved.getId());
        return saved;
    }

    // ─── 2. Libérer l'Escrow ─────────────────────────────────────────────────

    @Transactional
    public Transaction releaseEscrow(Long transactionId, Long buyerId) {
        Transaction tx = transactionRepository.findById(transactionId)
                .orElseThrow(() -> new IllegalArgumentException("Transaction introuvable"));

        if (!tx.getBuyer().getId().equals(buyerId)) {
            throw new IllegalStateException("Seul l'acheteur peut confirmer la réception.");
        }
        if (tx.getStatus() != TransactionStatus.ESCROWED) {
            throw new IllegalStateException("Cette transaction ne peut pas être libérée. Statut : " + tx.getStatus());
        }

        // Mettre à jour le statut
        tx.setStatus(TransactionStatus.RELEASED);
        tx.setConfirmedAt(LocalDateTime.now());
        tx.setReleasedAt(LocalDateTime.now());

        // Marquer la récolte comme livrée
        Harvest harvest = tx.getHarvest();
        harvest.setStatus(HarvestStatus.DELIVERED);
        harvestRepository.save(harvest);

        // Simuler les virements
        LOGGER.info("💸 Virement agriculteur  : " + tx.getFarmerShareFcfa() + " FCFA → " + tx.getFarmer().getPhoneNumber());
        if (tx.getTransporter() != null) {
            LOGGER.info("💸 Virement transporteur : " + tx.getTransporterShareFcfa() + " FCFA → " + tx.getTransporter().getPhoneNumber());
        }
        LOGGER.info("💸 Commission Ndjan-Soko : " + tx.getPlatformCommissionFcfa() + " FCFA");

        // Recalculer le hash après modification du statut
        tx.setCurrentHash(ledgerService.computeHash(tx));
        Transaction saved = transactionRepository.save(tx);

        LOGGER.info("✅ Escrow libéré — tx#" + transactionId);
        return saved;
    }

    // ─── 3. Simulation Mobile Money ───────────────────────────────────────────

    public String simulateMobileMoneyPayment(String phone, Double amount, String provider) {
        String refId = "SIM-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        LOGGER.info("📲 [SIMULATION " + provider + "] Débit de " + amount + " FCFA sur " + phone + " → Réf: " + refId);
        return refId;
    }
}
