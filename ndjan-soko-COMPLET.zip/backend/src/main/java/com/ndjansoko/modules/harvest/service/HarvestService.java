package com.ndjansoko.modules.harvest.service;

import com.ndjansoko.modules.auth.model.User;
import com.ndjansoko.modules.auth.repository.UserRepository;
import com.ndjansoko.modules.harvest.dto.HarvestCreateDto;
import com.ndjansoko.modules.harvest.model.*;
import com.ndjansoko.modules.harvest.repository.HarvestRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class HarvestService {

    private final HarvestRepository harvestRepository;
    private final UserRepository    userRepository;

    public HarvestService(HarvestRepository harvestRepository, UserRepository userRepository) {
        this.harvestRepository = harvestRepository;
        this.userRepository    = userRepository;
    }

    public Harvest createHarvest(HarvestCreateDto dto, Long farmerId) {
        User farmer = userRepository.findById(farmerId)
                .orElseThrow(() -> new IllegalArgumentException("Agriculteur introuvable"));

        Harvest h = new Harvest();
        h.setFarmer(farmer);
        h.setProductType(dto.getProductType());
        h.setQuantityKg(dto.getQuantityKg());
        h.setPricePerKgFcfa(dto.getPricePerKgFcfa());
        h.setVariety(dto.getVariety());
        h.setLatitude(dto.getLatitude());
        h.setLongitude(dto.getLongitude());
        h.setVillageName(dto.getVillageName());
        h.setRegion(dto.getRegion());
        h.setHarvestDate(dto.getHarvestDate());
        h.setCreatedOffline(dto.getCreatedOffline());
        h.setMaturityPercent(dto.getMaturityPercent());
        h.setStatus(HarvestStatus.PENDING_TRANSPORT);

        if (dto.getQualityCategory() != null) {
            try { h.setQualityCategory(QualityCategory.valueOf(dto.getQualityCategory())); }
            catch (IllegalArgumentException e) { h.setQualityCategory(QualityCategory.CAT_B); }
        }

        return harvestRepository.save(h);
    }

    public List<Harvest> getFarmerHarvests(Long farmerId) {
        return harvestRepository.findByFarmerIdOrderByCreatedAtDesc(farmerId);
    }

    public Double suggestPrice(String qualityCategory, String productType) {
        double base = switch (productType) {
            case "TOMATO"   -> 250.0;
            case "CASSAVA"  -> 100.0;
            case "PLANTAIN" -> 150.0;
            case "AVOCADO"  -> 200.0;
            case "PEPPER"   -> 500.0;
            default         -> 150.0;
        };
        return switch (qualityCategory) {
            case "CAT_A" -> base * 1.15;
            case "CAT_C" -> base * 0.75;
            default      -> base;
        };
    }

    public List<Harvest> getAvailableHarvests(String productType, String region, Double minQuantity) {
        List<Harvest> all = harvestRepository.findByProductTypeAndStatusOrderByCreatedAtDesc(
                productType != null ? ProductType.valueOf(productType) : ProductType.TOMATO,
                HarvestStatus.PENDING_TRANSPORT);
        if (minQuantity != null) {
            all = all.stream().filter(h -> h.getQuantityKg() >= minQuantity).toList();
        }
        if (region != null && !region.isBlank()) {
            all = all.stream().filter(h -> region.equalsIgnoreCase(h.getRegion())).toList();
        }
        return all;
    }
}
