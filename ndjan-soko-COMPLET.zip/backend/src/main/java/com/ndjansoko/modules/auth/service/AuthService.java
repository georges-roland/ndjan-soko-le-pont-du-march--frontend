package com.ndjansoko.modules.auth.service;

import com.ndjansoko.config.JwtService;
import com.ndjansoko.modules.auth.dto.*;
import com.ndjansoko.modules.auth.model.*;
import com.ndjansoko.modules.auth.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Random;
import java.util.logging.Logger;

/**
 * Service d'authentification par OTP SMS. RESPONSABLE : F
 */
@Service
public class AuthService {

    private static final Logger LOGGER = Logger.getLogger(AuthService.class.getName());
    private static final Random RANDOM = new Random();

    private final UserRepository userRepository;
    private final OtpRepository  otpRepository;
    private final JwtService     jwtService;

    public AuthService(UserRepository userRepository,
                       OtpRepository otpRepository,
                       JwtService jwtService) {
        this.userRepository = userRepository;
        this.otpRepository  = otpRepository;
        this.jwtService     = jwtService;
    }

    // ─── ÉTAPE 1 : Envoi de l'OTP ────────────────────────────────────────────

    @Transactional
    public String sendOtp(OtpRequestDto dto) {
        String phone = normalizePhone(dto.getPhoneNumber());

        // Invalider l'ancien OTP non utilisé si existant
        otpRepository.findTopByPhoneNumberAndUsedFalseOrderByIdDesc(phone)
                      .ifPresent(old -> {
                          old.setUsed(true);
                          otpRepository.save(old);
                      });

        // Générer un nouveau code à 6 chiffres
        String code = String.format("%06d", RANDOM.nextInt(999_999));

        OtpCode otp = new OtpCode();
        otp.setPhoneNumber(phone);
        otp.setCode(code);
        otp.setExpiresAt(LocalDateTime.now().plusMinutes(10));
        otp.setUsed(false);
        otpRepository.save(otp);

        // Simulation SMS : affichage dans les logs
        LOGGER.info("╔══════════════════════════════════╗");
        LOGGER.info("║  📱 SIMULATION SMS — Ndjan-Soko  ║");
        LOGGER.info("║  Numéro : " + phone              + "  ║");
        LOGGER.info("║  Code   : " + code               + "              ║");
        LOGGER.info("║  Expire : dans 10 minutes        ║");
        LOGGER.info("╚══════════════════════════════════╝");

        return "Code OTP envoyé au " + phone + " (voir les logs du serveur)";
    }

    // ─── ÉTAPE 2 : Vérification OTP → JWT ────────────────────────────────────

    @Transactional
    public String verifyOtp(OtpVerifyDto dto) {
        String phone = normalizePhone(dto.getPhoneNumber());

        // 1. Trouver le dernier OTP non utilisé
        OtpCode otp = otpRepository
                .findTopByPhoneNumberAndUsedFalseOrderByIdDesc(phone)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Aucun code OTP en attente. Demandez-en un nouveau."));

        // 2. Vérifier validité (non expiré + non utilisé)
        if (!otp.isValid()) {
            throw new IllegalArgumentException("Code OTP expiré. Demandez-en un nouveau.");
        }

        // 3. Vérifier que le code correspond
        if (!otp.getCode().equals(dto.getCode())) {
            throw new IllegalArgumentException("Code OTP incorrect.");
        }

        // 4. Marquer comme consommé (usage unique)
        otp.setUsed(true);
        otpRepository.save(otp);

        // 5. Créer l'utilisateur si première connexion
        User user = userRepository.findByPhoneNumber(phone)
                .orElseGet(() -> createNewUser(phone, dto.getRole()));

        // 6. Vérifier que le compte est actif
        if (!Boolean.TRUE.equals(user.getIsActive())) {
            throw new IllegalStateException(
                    "Compte suspendu (note < 3/5). Contactez le support Ndjan-Soko.");
        }

        // 7. Mettre à jour la date de dernière connexion
        user.setLastLogin(LocalDateTime.now());
        userRepository.save(user);

        // 8. Générer et retourner le JWT
        LOGGER.info("✅ Connexion réussie — " + phone + " (" + user.getRole() + ")");
        return jwtService.generateToken(user);
    }

    // ─── Méthodes privées ─────────────────────────────────────────────────────

    private User createNewUser(String phone, String roleStr) {
        if (roleStr == null || roleStr.isBlank()) {
            throw new IllegalArgumentException(
                    "Première connexion : précisez votre rôle (FARMER, BUYER, TRANSPORTER, HUB_MANAGER).");
        }
        UserRole role;
        try {
            role = UserRole.valueOf(roleStr.toUpperCase());
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException("Rôle invalide : " + roleStr);
        }

        User user = new User();
        user.setPhoneNumber(phone);
        user.setRole(role);
        user.setTrustScore(5.0);
        user.setTotalRatings(0);
        user.setIsActive(true);
        user.setCreatedAt(LocalDateTime.now());

        LOGGER.info("👤 Nouvel utilisateur créé : " + phone + " (" + role + ")");
        return userRepository.save(user);
    }

    private String normalizePhone(String phone) {
        phone = phone.replaceAll("\\s+", "");
        if (phone.startsWith("237")) phone = phone.substring(3);
        return phone;
    }
}
