package com.ndjansoko.modules.harvest.dto;

import com.ndjansoko.modules.harvest.model.ProductType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.time.LocalDate;

public class HarvestCreateDto {

    @NotNull(message = "Le type de produit est obligatoire")
    private ProductType productType;

    @NotNull @Positive
    private Double quantityKg;

    @NotNull @Positive
    private Double pricePerKgFcfa;

    private String variety;
    private Double latitude;
    private Double longitude;

    @NotBlank(message = "Le nom du village est obligatoire")
    private String villageName;

    private String region;
    private LocalDate harvestDate;
    private Boolean createdOffline = false;
    private String qualityCategory;
    private Double maturityPercent;

    public ProductType getProductType()           { return productType; }
    public void setProductType(ProductType v)     { this.productType = v; }
    public Double getQuantityKg()                 { return quantityKg; }
    public void setQuantityKg(Double v)           { this.quantityKg = v; }
    public Double getPricePerKgFcfa()             { return pricePerKgFcfa; }
    public void setPricePerKgFcfa(Double v)       { this.pricePerKgFcfa = v; }
    public String getVariety()                    { return variety; }
    public void setVariety(String v)              { this.variety = v; }
    public Double getLatitude()                   { return latitude; }
    public void setLatitude(Double v)             { this.latitude = v; }
    public Double getLongitude()                  { return longitude; }
    public void setLongitude(Double v)            { this.longitude = v; }
    public String getVillageName()                { return villageName; }
    public void setVillageName(String v)          { this.villageName = v; }
    public String getRegion()                     { return region; }
    public void setRegion(String v)               { this.region = v; }
    public LocalDate getHarvestDate()             { return harvestDate; }
    public void setHarvestDate(LocalDate v)       { this.harvestDate = v; }
    public Boolean getCreatedOffline()            { return createdOffline; }
    public void setCreatedOffline(Boolean v)      { this.createdOffline = v; }
    public String getQualityCategory()            { return qualityCategory; }
    public void setQualityCategory(String v)      { this.qualityCategory = v; }
    public Double getMaturityPercent()            { return maturityPercent; }
    public void setMaturityPercent(Double v)      { this.maturityPercent = v; }
}
