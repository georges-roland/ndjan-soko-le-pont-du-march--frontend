package com.ndjansoko.modules.logistics.model;

public enum LotStatus {
    PENDING_TRUCK,  // Cherche un camion
    TRUCK_ASSIGNED, // Camion trouvé
    AT_HUB,         // Déposé au hub
    LOADED,         // Chargé sur camion (QR scanné)
    DELIVERED       // Livré
}
