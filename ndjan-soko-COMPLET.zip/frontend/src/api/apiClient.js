/**
 * Client HTTP Axios centralisé - NE PAS MODIFIER SANS CONSULTER F
 * Toute l'équipe utilise ce fichier pour faire des appels API.
 *
 * COMMENT UTILISER :
 *   import apiClient from '../api/apiClient';
 *   const response = await apiClient.get('/harvests');
 */
import axios from 'axios';

const apiClient = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json' }
});

// Injecte automatiquement le JWT token dans chaque requête
apiClient.interceptors.request.use((config) => {
  const token = localStorage.getItem('ndjan_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Redirige vers login si le token expire (401)
apiClient.interceptors.response.use(
  response => response,
  error => {
    if (error.response?.status === 401) {
      localStorage.removeItem('ndjan_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default apiClient;
