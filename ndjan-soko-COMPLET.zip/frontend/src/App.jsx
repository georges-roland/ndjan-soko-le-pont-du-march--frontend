/**
 * Point d'entrée React - Routeur conditionnel par rôle.
 * RESPONSABLE : F (ne pas modifier la structure sans F)
 */
import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import LoginPage from './pages/auth/LoginPage';
import RegisterRolePage from './pages/auth/RegisterRolePage';
import FarmerDashboard from './pages/farmer/FarmerDashboard';
import CreateHarvestPage from './pages/farmer/CreateHarvestPage';
import MyHarvestsPage from './pages/farmer/MyHarvestsPage';
import BuyerDashboard from './pages/buyer/BuyerDashboard';
import MarketPricePage from './pages/buyer/MarketPricePage';
import HarvestCatalogPage from './pages/buyer/HarvestCatalogPage';
import PaymentEscrowPage from './pages/buyer/PaymentEscrowPage';
import TransporterDashboard from './pages/transporter/TransporterDashboard';
import DeclareTripPage from './pages/transporter/DeclareTripPage';
import AdminSecurityPage from './pages/admin/AdminSecurityPage';

const ProtectedRoute = ({ children, allowedRole }) => {
  const { user, role } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (allowedRole && role !== allowedRole) return <Navigate to="/login" />;
  return children;
};

const AppRoutes = () => {
  const { role } = useAuth();
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterRolePage />} />
      <Route path="/" element={
        role === 'FARMER' ? <Navigate to="/farmer" /> :
        role === 'BUYER' ? <Navigate to="/buyer" /> :
        role === 'TRANSPORTER' ? <Navigate to="/transporter" /> :
        <Navigate to="/login" />
      } />
      <Route path="/farmer" element={<ProtectedRoute allowedRole="FARMER"><FarmerDashboard /></ProtectedRoute>} />
      <Route path="/farmer/create" element={<ProtectedRoute allowedRole="FARMER"><CreateHarvestPage /></ProtectedRoute>} />
      <Route path="/farmer/my-harvests" element={<ProtectedRoute allowedRole="FARMER"><MyHarvestsPage /></ProtectedRoute>} />
      <Route path="/buyer" element={<ProtectedRoute allowedRole="BUYER"><BuyerDashboard /></ProtectedRoute>} />
      <Route path="/buyer/prices" element={<ProtectedRoute allowedRole="BUYER"><MarketPricePage /></ProtectedRoute>} />
      <Route path="/buyer/catalog" element={<ProtectedRoute allowedRole="BUYER"><HarvestCatalogPage /></ProtectedRoute>} />
      <Route path="/buyer/payment/:harvestId" element={<ProtectedRoute allowedRole="BUYER"><PaymentEscrowPage /></ProtectedRoute>} />
      <Route path="/transporter" element={<ProtectedRoute allowedRole="TRANSPORTER"><TransporterDashboard /></ProtectedRoute>} />
      <Route path="/transporter/declare-trip" element={<ProtectedRoute allowedRole="TRANSPORTER"><DeclareTripPage /></ProtectedRoute>} />
      <Route path="/admin/security" element={<AdminSecurityPage />} />
    </Routes>
  );
};

const App = () => (
  <AuthProvider>
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  </AuthProvider>
);

export default App;
