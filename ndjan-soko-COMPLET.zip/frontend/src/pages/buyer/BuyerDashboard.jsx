/**
 * Tableau de bord Acheteur. RESPONSABLE : R + D
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getTodayPrices } from '../../api/pricingApi';
import { useAuth } from '../../context/AuthContext';

const EMOJI = { TOMATO:'🍅', CASSAVA:'🥔', PLANTAIN:'🍌', AVOCADO:'🥑', PEPPER:'🌶️', MACABO:'🌿', ONION:'🧅' };
const MOCK = [
  { productType:'TOMATO', avgPricePerKgFcfa:275 },
  { productType:'PLANTAIN', avgPricePerKgFcfa:160 },
  { productType:'CASSAVA', avgPricePerKgFcfa:110 },
];

const S = {
  page: { minHeight:'100vh', background:'#F5F7FF', fontFamily:'Arial,sans-serif' },
  header: { background:'linear-gradient(135deg,#1565C0,#0D47A1)', color:'#fff', padding:'20px 24px' },
  name: { margin:0, fontSize:21, fontWeight:'bold' },
  sub: { margin:'4px 0 0', fontSize:13, opacity:.85 },
  body: { padding:20 },
  grid: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:20 },
  tile: (c) => ({ background:c, borderRadius:14, padding:'18px 14px', cursor:'pointer', textAlign:'center', boxShadow:'0 2px 8px rgba(0,0,0,.1)', border:'none', width:'100%' }),
  tileEmoji: { fontSize:30, display:'block', marginBottom:6 },
  tileLabel: { color:'#fff', fontWeight:'bold', fontSize:14 },
  priceWidget: { background:'#fff', borderRadius:14, padding:16, boxShadow:'0 2px 8px rgba(0,0,0,.07)', marginBottom:20 },
  priceTitle: { fontWeight:'bold', color:'#333', margin:'0 0 12px', fontSize:15 },
  priceRow: { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom:'1px solid #f5f5f5' },
  prodName: { display:'flex', alignItems:'center', gap:8, fontSize:14, color:'#333' },
  price: { fontWeight:'bold', color:'#1565C0', fontSize:15 },
};

const BuyerDashboard = () => {
  const [prices, setPrices] = useState([]);
  const { user }            = useAuth();
  const navigate            = useNavigate();

  useEffect(() => {
    getTodayPrices().then(r => setPrices(r.data?.length > 0 ? r.data : MOCK)).catch(() => setPrices(MOCK));
  }, []);

  return (
    <div style={S.page}>
      <div style={S.header}>
        <h2 style={S.name}>🛒 {user?.name || 'Espace Acheteur'}</h2>
        <p style={S.sub}>Bienvenue sur Ndjan-Soko</p>
      </div>
      <div style={S.body}>
        <div style={S.grid}>
          <button style={S.tile('#1565C0')} onClick={() => navigate('/buyer/catalog')}>
            <span style={S.tileEmoji}>🔍</span>
            <span style={S.tileLabel}>Catalogue</span>
          </button>
          <button style={S.tile('#1B7A3E')} onClick={() => navigate('/buyer/prices')}>
            <span style={S.tileEmoji}>📊</span>
            <span style={S.tileLabel}>Prix du marché</span>
          </button>
        </div>

        <div style={S.priceWidget}>
          <p style={S.priceTitle}>📈 Cours du jour</p>
          {prices.slice(0,4).map((p,i) => (
            <div key={i} style={S.priceRow}>
              <span style={S.prodName}>{EMOJI[p.productType]||'📦'} {p.productType}</span>
              <span style={S.price}>{p.avgPricePerKgFcfa} FCFA/kg</span>
            </div>
          ))}
          <p style={{fontSize:12, color:'#aaa', margin:'10px 0 0', textAlign:'right', cursor:'pointer'}} onClick={() => navigate('/buyer/prices')}>
            Voir tous les prix →
          </p>
        </div>
      </div>
    </div>
  );
};
export default BuyerDashboard;
