/**
 * Bourse des prix en temps réel. RESPONSABLE : R
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getTodayPrices } from '../../api/pricingApi';

const EMOJI = { TOMATO:'🍅', CASSAVA:'🥔', PLANTAIN:'🍌', AVOCADO:'🥑', PEPPER:'🌶️', MACABO:'🌿', ONION:'🧅', OTHER:'📦' };

// Prix fictifs de démonstration (affichés si le backend ne retourne rien)
const MOCK_PRICES = [
  { productType:'TOMATO',   marketName:'Mfoundi/Sandaga', avgPricePerKgFcfa:275, minPrice:200, maxPrice:350 },
  { productType:'CASSAVA',  marketName:'Mokolo',          avgPricePerKgFcfa:110, minPrice:80,  maxPrice:150 },
  { productType:'PLANTAIN', marketName:'Mfoundi',         avgPricePerKgFcfa:160, minPrice:120, maxPrice:200 },
  { productType:'AVOCADO',  marketName:'Sandaga',         avgPricePerKgFcfa:220, minPrice:150, maxPrice:300 },
  { productType:'PEPPER',   marketName:'Mokolo',          avgPricePerKgFcfa:550, minPrice:400, maxPrice:700 },
  { productType:'MACABO',   marketName:'Mfoundi',         avgPricePerKgFcfa:130, minPrice:90,  maxPrice:180 },
];

const S = {
  page: { minHeight:'100vh', background:'#F5F7FF', fontFamily:'Arial,sans-serif' },
  header: { background:'linear-gradient(135deg,#1565C0,#0D47A1)', color:'#fff', padding:'20px 24px', display:'flex', alignItems:'center', gap:12 },
  back: { background:'none', border:'none', color:'#fff', fontSize:22, cursor:'pointer' },
  title: { margin:0, fontSize:20, fontWeight:'bold' },
  date: { margin:'4px 0 0', fontSize:12, opacity:.85 },
  body: { padding:20 },
  intro: { background:'#E3F2FD', borderRadius:12, padding:'12px 16px', fontSize:13, color:'#1565C0', marginBottom:16, lineHeight:1.5 },
  card: { background:'#fff', borderRadius:14, padding:'16px 18px', marginBottom:12, boxShadow:'0 2px 8px rgba(0,0,0,.07)' },
  cardTop: { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:8 },
  productName: { fontWeight:'bold', fontSize:17, color:'#222' },
  avgPrice: { fontSize:22, fontWeight:'bold', color:'#1565C0' },
  unit: { fontSize:12, color:'#888', marginLeft:2 },
  barRow: { display:'flex', alignItems:'center', gap:8, margin:'8px 0 4px' },
  bar: (pct) => ({ flex:1, height:8, borderRadius:4, background:`linear-gradient(to right, #1565C0 ${pct}%, #e0e0e0 ${pct}%)` }),
  range: { display:'flex', justifyContent:'space-between', fontSize:12, color:'#888' },
  market: { fontSize:12, color:'#aaa', marginTop:4 },
  loading: { textAlign:'center', padding:40, color:'#888' },
};

const MarketPricePage = () => {
  const [prices, setPrices] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const today = new Date().toLocaleDateString('fr-FR', { weekday:'long', day:'numeric', month:'long' });

  useEffect(() => {
    getTodayPrices()
      .then(r => setPrices(r.data?.length > 0 ? r.data : MOCK_PRICES))
      .catch(() => setPrices(MOCK_PRICES))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => navigate('/buyer')}>←</button>
        <div>
          <h2 style={S.title}>📊 Bourse des Prix</h2>
          <p style={S.date}>📅 {today.charAt(0).toUpperCase()+today.slice(1)}</p>
        </div>
      </div>
      <div style={S.body}>
        <div style={S.intro}>
          📍 Prix relevés sur les marchés <strong>Mfoundi, Mokolo (Yaoundé)</strong> et <strong>Sandaga (Douala)</strong>. Ces cours servent de référence pour éviter que les agriculteurs vendent à perte.
        </div>
        {loading && <p style={S.loading}>Chargement des cours du jour...</p>}
        {prices.map((p, i) => {
          const range = p.maxPrice - p.minPrice;
          const pct = range > 0 ? Math.round(((p.avgPricePerKgFcfa - p.minPrice) / range) * 100) : 50;
          return (
            <div key={i} style={S.card}>
              <div style={S.cardTop}>
                <span style={S.productName}>{EMOJI[p.productType]||'📦'} {p.productType}</span>
                <span><span style={S.avgPrice}>{p.avgPricePerKgFcfa}</span><span style={S.unit}> FCFA/kg</span></span>
              </div>
              <div style={S.barRow}>
                <span style={{fontSize:12, color:'#888', width:30}}>{p.minPrice}</span>
                <div style={S.bar(pct)} />
                <span style={{fontSize:12, color:'#888', width:30, textAlign:'right'}}>{p.maxPrice}</span>
              </div>
              <div style={S.range}><span>Min (FCFA/kg)</span><span>Max (FCFA/kg)</span></div>
              <p style={S.market}>📍 Marché de référence : {p.marketName}</p>
            </div>
          );
        })}
      </div>
    </div>
  );
};
export default MarketPricePage;
