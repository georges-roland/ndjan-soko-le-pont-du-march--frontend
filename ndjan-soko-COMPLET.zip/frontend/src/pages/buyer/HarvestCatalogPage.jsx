/**
 * Catalogue des récoltes disponibles. RESPONSABLE : R
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAvailableHarvests } from '../../api/harvestApi';

const EMOJI = { TOMATO:'🍅', CASSAVA:'🥔', PLANTAIN:'🍌', AVOCADO:'🥑', PEPPER:'🌶️', MACABO:'🌿', ONION:'🧅', OTHER:'📦' };
const PRODUCTS = ['','TOMATO','CASSAVA','PLANTAIN','AVOCADO','PEPPER','MACABO'];
const REGIONS  = ['','Ouest','Littoral','Centre','Sud-Ouest','Nord-Ouest'];

const S = {
  page: { minHeight:'100vh', background:'#F5F7FF', fontFamily:'Arial,sans-serif' },
  header: { background:'linear-gradient(135deg,#1565C0,#0D47A1)', color:'#fff', padding:'20px 24px', display:'flex', alignItems:'center', gap:12 },
  back: { background:'none', border:'none', color:'#fff', fontSize:22, cursor:'pointer' },
  title: { margin:0, fontSize:20, fontWeight:'bold' },
  filters: { display:'flex', gap:8, padding:'12px 20px', background:'#fff', borderBottom:'1px solid #eee', flexWrap:'wrap' },
  select: { padding:'7px 12px', border:'1px solid #ddd', borderRadius:20, fontSize:13, background:'#fafafa' },
  body: { padding:16 },
  card: { background:'#fff', borderRadius:14, padding:16, marginBottom:12, boxShadow:'0 2px 8px rgba(0,0,0,.07)' },
  top: { display:'flex', justifyContent:'space-between', alignItems:'flex-start' },
  product: { fontWeight:'bold', fontSize:17, color:'#222', margin:0 },
  price: { fontSize:20, fontWeight:'bold', color:'#1565C0' },
  unit: { fontSize:12, color:'#888' },
  detail: { fontSize:13, color:'#555', margin:'4px 0' },
  buyBtn: { marginTop:12, width:'100%', padding:'11px 0', background:'#1565C0', color:'#fff', border:'none', borderRadius:10, fontWeight:'bold', fontSize:15, cursor:'pointer' },
  badge: { display:'inline-block', padding:'3px 10px', borderRadius:20, fontSize:11, fontWeight:'bold', background:'#E8F5E9', color:'#1B7A3E' },
  empty: { textAlign:'center', padding:40, color:'#aaa' },
};

const HarvestCatalogPage = () => {
  const [harvests, setHarvests]   = useState([]);
  const [loading, setLoading]     = useState(true);
  const [product, setProduct]     = useState('');
  const [region, setRegion]       = useState('');
  const [minQty, setMinQty]       = useState('');
  const navigate = useNavigate();

  const load = () => {
    setLoading(true);
    getAvailableHarvests({ productType: product||undefined, region: region||undefined, minQuantity: minQty||undefined })
      .then(r => setHarvests(r.data))
      .catch(() => setHarvests([]))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, [product, region]);

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => navigate('/buyer')}>←</button>
        <h2 style={S.title}>🔍 Catalogue des récoltes</h2>
      </div>

      <div style={S.filters}>
        <select style={S.select} value={product} onChange={e => setProduct(e.target.value)}>
          <option value="">Tous les produits</option>
          {PRODUCTS.filter(Boolean).map(p => <option key={p} value={p}>{p}</option>)}
        </select>
        <select style={S.select} value={region} onChange={e => setRegion(e.target.value)}>
          <option value="">Toutes les régions</option>
          {REGIONS.filter(Boolean).map(r => <option key={r} value={r}>{r}</option>)}
        </select>
        <select style={S.select} value={minQty} onChange={e => setMinQty(e.target.value)}>
          <option value="">Toute quantité</option>
          <option value="100">Min 100 kg</option>
          <option value="500">Min 500 kg</option>
          <option value="1000">Min 1 tonne</option>
        </select>
      </div>

      <div style={S.body}>
        {loading && <p style={S.empty}>Chargement...</p>}
        {!loading && harvests.length === 0 && <p style={S.empty}>Aucune récolte disponible pour ces critères.</p>}
        {harvests.map(h => (
          <div key={h.id} style={S.card}>
            <div style={S.top}>
              <p style={S.product}>{EMOJI[h.productType]||'📦'} {h.productType}</p>
              <div style={{textAlign:'right'}}>
                <div style={S.price}>{h.pricePerKgFcfa}</div>
                <div style={S.unit}>FCFA/kg</div>
              </div>
            </div>
            <p style={S.detail}>⚖️ {h.quantityKg} kg disponibles · Total : {(h.quantityKg*h.pricePerKgFcfa).toLocaleString()} FCFA</p>
            <p style={S.detail}>📍 {h.villageName}{h.region ? ` — ${h.region}` : ''}</p>
            {h.qualityCategory && <span style={S.badge}>IA : {h.qualityCategory}</span>}
            <button style={S.buyBtn} onClick={() => navigate(`/buyer/payment/${h.id}`)}>
              🛒 Acheter cette récolte
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
export default HarvestCatalogPage;
