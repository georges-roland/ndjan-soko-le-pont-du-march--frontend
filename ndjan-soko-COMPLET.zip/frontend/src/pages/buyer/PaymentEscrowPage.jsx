/**
 * Page de paiement sécurisé Escrow. RESPONSABLE : D
 */
import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { initiateEscrow, confirmReceipt } from '../../api/paymentApi';

const S = {
  page: { minHeight: '100vh', background: '#F5F7FF', fontFamily: 'Arial, sans-serif' },
  header: { background: '#6A1B9A', color: '#fff', padding: '20px 24px', display: 'flex', alignItems: 'center', gap: 12 },
  back: { background: 'none', border: 'none', color: '#fff', fontSize: 20, cursor: 'pointer' },
  title: { margin: 0, fontSize: 20, fontWeight: 'bold' },
  body: { padding: 20, maxWidth: 460, margin: '0 auto' },
  steps: { display: 'flex', justifyContent: 'center', gap: 8, margin: '20px 0' },
  step: (active, done) => ({
    width: 36, height: 36, borderRadius: '50%', display: 'flex', alignItems: 'center',
    justifyContent: 'center', fontWeight: 'bold', fontSize: 14,
    background: done ? '#6A1B9A' : active ? '#CE93D8' : '#e0e0e0',
    color: done || active ? '#fff' : '#aaa',
  }),
  stepLine: (done) => ({ flex: 1, height: 3, background: done ? '#6A1B9A' : '#e0e0e0', alignSelf: 'center' }),
  card: { background: '#fff', borderRadius: 16, padding: 20, marginBottom: 16, boxShadow: '0 2px 10px rgba(0,0,0,0.08)' },
  label: { color: '#888', fontSize: 13, margin: '0 0 4px' },
  value: { color: '#222', fontSize: 16, fontWeight: 'bold', margin: '0 0 12px' },
  bigAmount: { textAlign: 'center', fontSize: 32, fontWeight: 'bold', color: '#6A1B9A', margin: '8px 0 4px' },
  providerRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, margin: '16px 0' },
  providerBtn: (selected) => ({
    padding: '14px 10px', borderRadius: 12, border: `2px solid ${selected ? '#6A1B9A' : '#e0e0e0'}`,
    background: selected ? '#F3E5F5' : '#fafafa', cursor: 'pointer', textAlign: 'center',
    fontWeight: 'bold', color: selected ? '#6A1B9A' : '#555', transition: 'all .2s',
  }),
  btn: (color) => ({
    width: '100%', padding: 14, background: color || '#6A1B9A', color: '#fff',
    border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 'bold',
    cursor: 'pointer', marginTop: 8,
  }),
  lockAnim: { textAlign: 'center', fontSize: 72, margin: '20px 0 8px' },
  lockText: { textAlign: 'center', color: '#6A1B9A', fontWeight: 'bold', fontSize: 18, margin: '0 0 8px' },
  lockSub: { textAlign: 'center', color: '#777', fontSize: 13, lineHeight: 1.5, margin: '0 0 20px' },
  infoBox: (color) => ({ background: color + '22', border: `1px solid ${color}44`, borderRadius: 10, padding: '10px 14px', marginTop: 10, fontSize: 13, color: '#333' }),
  error: { background: '#FFEBEE', color: '#B71C1C', padding: '10px 14px', borderRadius: 10, fontSize: 13, marginTop: 10 },
  successBig: { textAlign: 'center', fontSize: 56, marginBottom: 8 },
};

const HARVEST_MOCK = { productType: 'TOMATO', quantityKg: 500, pricePerKgFcfa: 250 };

const PaymentEscrowPage = () => {
  const { harvestId }         = useParams();
  const navigate              = useNavigate();
  const [step, setStep]       = useState(1);
  const [provider, setProvider] = useState('');
  const [tx, setTx]           = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  const total       = HARVEST_MOCK.quantityKg * HARVEST_MOCK.pricePerKgFcfa;
  const commission  = total * 0.04;
  const farmerPart  = (total - commission) * 0.80;
  const transportPart = (total - commission) * 0.20;

  const handlePay = async () => {
    if (!provider) { setError('Choisissez un moyen de paiement.'); return; }
    setError(''); setLoading(true);
    try {
      const r = await initiateEscrow(harvestId, provider);
      setTx(r.data);
      setStep(2);
    } catch (e) {
      setError(e.response?.data || 'Erreur lors du paiement.');
    } finally { setLoading(false); }
  };

  const handleConfirm = async () => {
    if (!tx) return;
    setLoading(true);
    try {
      await confirmReceipt(tx.id);
      setStep(3);
    } catch (e) {
      setError(e.response?.data || 'Erreur lors de la confirmation.');
    } finally { setLoading(false); }
  };

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => navigate('/buyer/catalog')}>←</button>
        <h2 style={S.title}>🔐 Paiement Sécurisé</h2>
      </div>
      <div style={S.body}>

        {/* Barre de progression */}
        <div style={S.steps}>
          {[1,2,3].map((n, i) => (
            <React.Fragment key={n}>
              <div style={S.step(step === n, step > n)}>{step > n ? '✓' : n}</div>
              {i < 2 && <div style={S.stepLine(step > n)} />}
            </React.Fragment>
          ))}
        </div>

        {error && <div style={S.error}>⚠️ {error}</div>}

        {/* ── ÉTAPE 1 : Résumé & choix du moyen de paiement ── */}
        {step === 1 && (
          <>
            <div style={S.card}>
              <p style={S.label}>Produit</p>
              <p style={S.value}>🍅 Tomates — {HARVEST_MOCK.quantityKg} kg</p>
              <p style={S.label}>Prix unitaire</p>
              <p style={S.value}>{HARVEST_MOCK.pricePerKgFcfa} FCFA/kg</p>
              <hr style={{ border: 'none', borderTop: '1px solid #f0f0f0', margin: '8px 0' }} />
              <p style={S.label}>Sous-total marchandise</p>
              <p style={{ ...S.value, color: '#333' }}>{total.toLocaleString()} FCFA</p>
              <p style={S.label}>Commission Ndjan-Soko (4%)</p>
              <p style={{ ...S.value, color: '#E65100' }}>− {commission.toLocaleString()} FCFA</p>
              <p style={S.label}>Part agriculteur</p>
              <p style={{ ...S.value, color: '#1B7A3E' }}>{farmerPart.toLocaleString()} FCFA</p>
              <p style={S.label}>Part transporteur</p>
              <p style={{ ...S.value, color: '#1565C0' }}>{transportPart.toLocaleString()} FCFA</p>
            </div>

            <p style={{ fontWeight: 'bold', margin: '0 0 8px', color: '#333' }}>Moyen de paiement</p>
            <div style={S.providerRow}>
              <div style={S.providerBtn(provider === 'MTN_MOMO')} onClick={() => setProvider('MTN_MOMO')}>
                📱 MTN MoMo
              </div>
              <div style={S.providerBtn(provider === 'ORANGE_MONEY')} onClick={() => setProvider('ORANGE_MONEY')}>
                🟠 Orange Money
              </div>
            </div>

            <div style={S.bigAmount}>{total.toLocaleString()} FCFA</div>
            <p style={{ textAlign: 'center', color: '#888', fontSize: 12, margin: '0 0 16px' }}>
              Montant total à débiter
            </p>

            <button style={S.btn()} onClick={handlePay} disabled={loading}>
              {loading ? 'Traitement...' : '🔐 Payer et sécuriser les fonds'}
            </button>
          </>
        )}

        {/* ── ÉTAPE 2 : Fonds sécurisés, attente livraison ── */}
        {step === 2 && (
          <>
            <div style={S.lockAnim}>🔒</div>
            <p style={S.lockText}>Fonds sécurisés par Ndjan-Soko</p>
            <p style={S.lockSub}>
              {total.toLocaleString()} FCFA sont bloqués dans notre séquestre.
              L'agriculteur et le transporteur sont notifiés et peuvent procéder à la livraison.
            </p>

            {tx && (
              <div style={S.infoBox('#6A1B9A')}>
                <strong>Référence transaction :</strong> {tx.externalTransactionId || 'SIM-XXXXXXXX'}<br />
                <strong>Statut :</strong> {tx.status}
              </div>
            )}

            <div style={S.infoBox('#1B7A3E')}>
              ✅ Confirmez la réception <strong>uniquement</strong> après avoir inspecté et accepté votre commande.
              Les fonds seront libérés immédiatement.
            </div>

            <button style={S.btn('#1B7A3E')} onClick={handleConfirm} disabled={loading}>
              {loading ? 'Traitement...' : "✅ J'ai reçu et accepté ma commande"}
            </button>
            <button style={{ ...S.btn('#888'), marginTop: 8 }} onClick={() => navigate('/buyer')}>
              Retour au tableau de bord
            </button>
          </>
        )}

        {/* ── ÉTAPE 3 : Succès ── */}
        {step === 3 && (
          <>
            <div style={S.successBig}>🎉</div>
            <p style={{ textAlign: 'center', fontWeight: 'bold', fontSize: 20, color: '#1B7A3E' }}>
              Transaction finalisée !
            </p>
            <p style={{ textAlign: 'center', color: '#555', fontSize: 14, marginBottom: 20 }}>
              Les fonds ont été distribués automatiquement.
            </p>
            <div style={S.card}>
              <p style={S.label}>Agriculteur a reçu</p>
              <p style={{ ...S.value, color: '#1B7A3E' }}>{farmerPart.toLocaleString()} FCFA</p>
              <p style={S.label}>Transporteur a reçu</p>
              <p style={{ ...S.value, color: '#1565C0' }}>{transportPart.toLocaleString()} FCFA</p>
              <p style={S.label}>Commission Ndjan-Soko</p>
              <p style={{ ...S.value, color: '#E65100' }}>{commission.toLocaleString()} FCFA</p>
            </div>
            <button style={S.btn()} onClick={() => navigate('/buyer')}>
              Retour au tableau de bord
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default PaymentEscrowPage;
