/**
 * Formulaire de publication d'une récolte — 4 étapes. RESPONSABLE : R
 */
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { createHarvest, suggestPrice } from '../../api/harvestApi';

const PRODUCTS = [
  { value:'TOMATO',   label:'🍅 Tomate'   },
  { value:'CASSAVA',  label:'🥔 Manioc'   },
  { value:'PLANTAIN', label:'🍌 Plantain' },
  { value:'AVOCADO',  label:'🥑 Avocat'   },
  { value:'PEPPER',   label:'🌶️ Piment'   },
  { value:'MACABO',   label:'🌿 Macabo'   },
  { value:'ONION',    label:'🧅 Oignon'   },
  { value:'OTHER',    label:'📦 Autre'    },
];

const S = {
  page: { minHeight:'100vh', background:'#F5F9F6', fontFamily:'Arial,sans-serif' },
  header: { background:'#1B7A3E', color:'#fff', padding:'20px 24px', display:'flex', alignItems:'center', gap:12 },
  back: { background:'none', border:'none', color:'#fff', fontSize:22, cursor:'pointer' },
  title: { margin:0, fontSize:20, fontWeight:'bold' },
  progress: { display:'flex', padding:'16px 24px', gap:8, alignItems:'center' },
  dot: (a,d) => ({ width:32, height:32, borderRadius:'50%', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'bold', fontSize:13, background: d?'#1B7A3E':a?'#A5D6A7':'#e0e0e0', color: d||a?'#fff':'#999' }),
  line: (d) => ({ flex:1, height:3, background: d?'#1B7A3E':'#e0e0e0' }),
  body: { padding:20, maxWidth:480, margin:'0 auto' },
  label: { display:'block', fontWeight:'bold', fontSize:14, color:'#333', margin:'14px 0 6px' },
  input: { width:'100%', padding:'11px 14px', border:'2px solid #e0e0e0', borderRadius:10, fontSize:15, outline:'none', boxSizing:'border-box' },
  select: { width:'100%', padding:'11px 14px', border:'2px solid #e0e0e0', borderRadius:10, fontSize:15, background:'#fff', boxSizing:'border-box' },
  row2: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 },
  btn: (c) => ({ width:'100%', padding:14, marginTop:20, background:c||'#1B7A3E', color:'#fff', border:'none', borderRadius:12, fontSize:16, fontWeight:'bold', cursor:'pointer' }),
  btnOut: { width:'100%', padding:14, marginTop:10, background:'transparent', color:'#1B7A3E', border:'2px solid #1B7A3E', borderRadius:12, fontSize:15, fontWeight:'bold', cursor:'pointer' },
  aiBox: { background:'#E8F5E9', border:'1px solid #A5D6A7', borderRadius:12, padding:'14px 16px', margin:'14px 0' },
  suggestPill: { display:'inline-block', background:'#1B7A3E', color:'#fff', borderRadius:20, padding:'4px 14px', fontSize:14, fontWeight:'bold', marginTop:6 },
  error: { background:'#FFEBEE', color:'#B71C1C', padding:'10px 14px', borderRadius:10, fontSize:13, marginTop:10 },
  success: { background:'#E8F5E9', color:'#1B7A3E', padding:'14px 16px', borderRadius:12, fontSize:14, marginTop:10 },
  gpsBtn: { padding:'10px 16px', background:'#E3F2FD', color:'#1565C0', border:'1px solid #90CAF9', borderRadius:10, cursor:'pointer', fontSize:13, fontWeight:'bold' },
  summary: { background:'#fff', borderRadius:14, padding:20, boxShadow:'0 2px 8px rgba(0,0,0,.08)' },
  sumRow: { display:'flex', justifyContent:'space-between', padding:'6px 0', borderBottom:'1px solid #f0f0f0', fontSize:14 },
};

const QUALITY_LABELS = { CAT_A:{ label:'Catégorie A — Parfaite 🌟', color:'#1B7A3E' }, CAT_B:{ label:'Catégorie B — Bonne ✅', color:'#1565C0' }, CAT_C:{ label:'Catégorie C — À écouler 🔶', color:'#E65100' } };

const CreateHarvestPage = () => {
  const [step, setStep]     = useState(1);
  const [form, setForm]     = useState({ productType:'', quantityKg:'', pricePerKgFcfa:'', villageName:'', region:'', qualityCategory:'CAT_B', maturityPercent:80 });
  const [aiDone, setAiDone] = useState(false);
  const [suggested, setSuggested] = useState(null);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [coords, setCoords] = useState({ lat:null, lng:null });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  const set = (k,v) => setForm(f => ({...f,[k]:v}));

  // Simulation analyse IA
  const simulateAI = async () => {
    setAiDone(false); setError('');
    await new Promise(r => setTimeout(r, 1500)); // simulation délai
    const cats = ['CAT_A','CAT_B','CAT_C'];
    const cat = cats[Math.floor(Math.random()*3)];
    const maturite = Math.floor(65 + Math.random()*35);
    set('qualityCategory', cat); set('maturityPercent', maturite);
    setAiDone(true);
    if (form.productType) {
      try {
        const r = await suggestPrice(cat, form.productType);
        setSuggested(r.data);
        set('pricePerKgFcfa', String(Math.round(r.data)));
      } catch { setSuggested(null); }
    }
  };

  // GPS
  const handleGps = () => {
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      pos => { setCoords({ lat:pos.coords.latitude, lng:pos.coords.longitude }); setGpsLoading(false); },
      ()  => { setError("Impossible d'accéder au GPS. Entrez le village manuellement."); setGpsLoading(false); }
    );
  };

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      await createHarvest({
        productType: form.productType,
        quantityKg: parseFloat(form.quantityKg),
        pricePerKgFcfa: parseFloat(form.pricePerKgFcfa),
        villageName: form.villageName,
        region: form.region,
        qualityCategory: form.qualityCategory,
        maturityPercent: form.maturityPercent,
        latitude: coords.lat,
        longitude: coords.lng,
        createdOffline: false,
      });
      setSuccess(true);
      setTimeout(() => navigate('/farmer'), 2500);
    } catch(e) {
      setError(e.response?.data || 'Erreur réseau. Réessayez.');
    } finally { setLoading(false); }
  };

  if (success) return (
    <div style={{...S.page, display:'flex', alignItems:'center', justifyContent:'center'}}>
      <div style={{textAlign:'center', padding:40}}>
        <div style={{fontSize:72}}>🎉</div>
        <p style={{fontSize:22, fontWeight:'bold', color:'#1B7A3E'}}>Annonce publiée !</p>
        <p style={{color:'#555'}}>Votre récolte est visible par les acheteurs de Douala et Yaoundé.</p>
      </div>
    </div>
  );

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => step > 1 ? setStep(s=>s-1) : navigate('/farmer')}>←</button>
        <h2 style={S.title}>📸 Publier une récolte</h2>
      </div>

      {/* Barre de progression */}
      <div style={S.progress}>
        {[1,2,3,4].map((n,i) => (
          <React.Fragment key={n}>
            <div style={S.dot(step===n, step>n)}>{step>n?'✓':n}</div>
            {i<3 && <div style={S.line(step>n)} />}
          </React.Fragment>
        ))}
      </div>

      <div style={S.body}>
        {error && <div style={S.error}>⚠️ {error}</div>}

        {/* ÉTAPE 1 : Analyse IA */}
        {step === 1 && (
          <>
            <label style={S.label}>Produit</label>
            <select style={S.select} value={form.productType} onChange={e => set('productType', e.target.value)}>
              <option value="">Choisir le produit...</option>
              {PRODUCTS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
            </select>

            <label style={S.label}>Photo de la récolte (analyse IA)</label>
            <div style={{border:'2px dashed #A5D6A7', borderRadius:12, padding:30, textAlign:'center', background:'#F9FBF9'}}>
              <div style={{fontSize:40, marginBottom:8}}>📷</div>
              <p style={{color:'#555', fontSize:13, margin:'0 0 12px'}}>Prenez une photo de votre récolte pour l'analyser automatiquement</p>
              <button style={{...S.gpsBtn, background:'#1B7A3E', color:'#fff', border:'none', padding:'10px 20px'}} onClick={simulateAI} disabled={!form.productType}>
                🤖 Analyser avec l'IA
              </button>
            </div>

            {aiDone && (
              <div style={S.aiBox}>
                <p style={{margin:'0 0 4px', fontWeight:'bold', color:'#1B7A3E'}}>✅ Analyse terminée</p>
                <p style={{margin:'2px 0', fontSize:14, color:QUALITY_LABELS[form.qualityCategory]?.color}}>{QUALITY_LABELS[form.qualityCategory]?.label}</p>
                <p style={{margin:'2px 0', fontSize:13, color:'#555'}}>Maturité détectée : {form.maturityPercent}%</p>
                {suggested && <span style={S.suggestPill}>Prix suggéré : {Math.round(suggested)} FCFA/kg</span>}
              </div>
            )}

            <button style={S.btn()} onClick={() => { if(!form.productType){setError('Choisissez un produit.');return;} setError(''); setStep(2); }}>
              Continuer →
            </button>
          </>
        )}

        {/* ÉTAPE 2 : Quantité & Prix */}
        {step === 2 && (
          <>
            <div style={S.row2}>
              <div>
                <label style={S.label}>Quantité (kg)</label>
                <input style={S.input} type="number" placeholder="500" value={form.quantityKg} onChange={e=>set('quantityKg',e.target.value)} />
              </div>
              <div>
                <label style={S.label}>Prix (FCFA/kg)</label>
                <input style={S.input} type="number" placeholder="250" value={form.pricePerKgFcfa} onChange={e=>set('pricePerKgFcfa',e.target.value)} />
              </div>
            </div>
            <button style={S.btn()} onClick={() => { if(!form.quantityKg||!form.pricePerKgFcfa){setError('Remplissez quantité et prix.');return;} setError(''); setStep(3); }}>
              Continuer →
            </button>
          </>
        )}

        {/* ÉTAPE 3 : Localisation */}
        {step === 3 && (
          <>
            <label style={S.label}>Village / Lieu de récolte</label>
            <input style={S.input} placeholder="Ex: Foumbot, Santa, Moungo..." value={form.villageName} onChange={e=>set('villageName',e.target.value)} />
            <label style={S.label}>Région</label>
            <select style={S.select} value={form.region} onChange={e=>set('region',e.target.value)}>
              <option value="">Choisir...</option>
              {['Ouest','Littoral','Centre','Sud-Ouest','Nord-Ouest','Sud','Est','Adamaoua','Nord','Extrême-Nord'].map(r=><option key={r} value={r}>{r}</option>)}
            </select>
            <label style={S.label}>Position GPS (optionnel)</label>
            <div style={{display:'flex', gap:10, alignItems:'center'}}>
              <button style={S.gpsBtn} onClick={handleGps} disabled={gpsLoading}>
                {gpsLoading ? '📡 Localisation...' : '📍 Utiliser ma position'}
              </button>
              {coords.lat && <span style={{fontSize:12,color:'#1B7A3E'}}>✅ {coords.lat.toFixed(4)}, {coords.lng.toFixed(4)}</span>}
            </div>
            <button style={S.btn()} onClick={() => { if(!form.villageName){setError('Entrez le nom du village.');return;} setError(''); setStep(4); }}>
              Continuer →
            </button>
          </>
        )}

        {/* ÉTAPE 4 : Confirmation */}
        {step === 4 && (
          <>
            <div style={S.summary}>
              <p style={{margin:'0 0 12px', fontWeight:'bold', fontSize:16, color:'#1B7A3E'}}>📋 Récapitulatif</p>
              {[
                ['Produit', PRODUCTS.find(p=>p.value===form.productType)?.label || form.productType],
                ['Quantité', form.quantityKg + ' kg'],
                ['Prix', form.pricePerKgFcfa + ' FCFA/kg'],
                ['Total estimé', (parseFloat(form.quantityKg||0)*parseFloat(form.pricePerKgFcfa||0)).toLocaleString() + ' FCFA'],
                ['Village', form.villageName],
                ['Région', form.region],
                ['Qualité IA', QUALITY_LABELS[form.qualityCategory]?.label],
              ].map(([k,v]) => (
                <div key={k} style={S.sumRow}>
                  <span style={{color:'#888'}}>{k}</span>
                  <span style={{fontWeight:'bold', color:'#222'}}>{v}</span>
                </div>
              ))}
            </div>
            <button style={S.btn()} onClick={handleSubmit} disabled={loading}>
              {loading ? '⏳ Publication en cours...' : '🚀 Publier mon annonce'}
            </button>
            <button style={S.btnOut} onClick={() => setStep(3)}>← Modifier</button>
          </>
        )}
      </div>
    </div>
  );
};
export default CreateHarvestPage;
