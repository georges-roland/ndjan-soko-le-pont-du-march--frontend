/**
 * Liste des récoltes de l'agriculteur connecté. RESPONSABLE : R
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getMyHarvests } from '../../api/harvestApi';

const EMOJI = { TOMATO:'🍅', CASSAVA:'🥔', PLANTAIN:'🍌', AVOCADO:'🥑', PEPPER:'🌶️', MACABO:'🌿', ONION:'🧅', OTHER:'📦' };
const STATUS = {
  PENDING_TRANSPORT: { label:'En attente camion', bg:'#FFF3E0', color:'#E65100' },
  GROUPED:           { label:'Groupage validé',   bg:'#E3F2FD', color:'#1565C0' },
  IN_TRANSIT:        { label:'En transit 🚚',     bg:'#E8F5E9', color:'#1B7A3E' },
  DELIVERED:         { label:'Livré ✅',           bg:'#F5F5F5', color:'#666'    },
  AT_HUB:            { label:'Au hub 🏪',         bg:'#F3E5F5', color:'#6A1B9A' },
  CANCELLED:         { label:'Annulé',            bg:'#FFEBEE', color:'#B71C1C' },
};

const S = {
  page: { minHeight:'100vh', background:'#F5F9F6', fontFamily:'Arial,sans-serif' },
  header: { background:'#1B7A3E', color:'#fff', padding:'20px 24px', display:'flex', alignItems:'center', gap:12 },
  back: { background:'none', border:'none', color:'#fff', fontSize:22, cursor:'pointer' },
  title: { margin:0, fontSize:20, fontWeight:'bold' },
  body: { padding:20 },
  card: { background:'#fff', borderRadius:14, padding:16, marginBottom:12, boxShadow:'0 2px 8px rgba(0,0,0,.07)' },
  top: { display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8 },
  product: { fontWeight:'bold', fontSize:17, color:'#1B7A3E', margin:0 },
  badge: (s) => ({ padding:'4px 12px', borderRadius:20, fontSize:11, fontWeight:'bold', background:STATUS[s]?.bg||'#eee', color:STATUS[s]?.color||'#333' }),
  detail: { fontSize:13, color:'#555', margin:'3px 0' },
  qrBox: { background:'#F3E5F5', borderRadius:8, padding:'6px 10px', marginTop:8, fontSize:12, color:'#6A1B9A', fontFamily:'monospace' },
  empty: { textAlign:'center', padding:40, color:'#aaa' },
  addBtn: { position:'fixed', bottom:24, right:24, width:56, height:56, borderRadius:'50%', background:'#1B7A3E', color:'#fff', fontSize:28, border:'none', cursor:'pointer', boxShadow:'0 4px 16px rgba(0,0,0,.25)', display:'flex', alignItems:'center', justifyContent:'center' },
};

const MyHarvestsPage = () => {
  const [harvests, setHarvests] = useState([]);
  const [loading, setLoading]   = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    getMyHarvests().then(r => setHarvests(r.data)).catch(()=>{}).finally(()=>setLoading(false));
  }, []);

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => navigate('/farmer')}>←</button>
        <h2 style={S.title}>📦 Mes annonces ({harvests.length})</h2>
      </div>
      <div style={S.body}>
        {loading && <p style={S.empty}>Chargement...</p>}
        {!loading && harvests.length === 0 && (
          <div style={S.empty}>
            <div style={{fontSize:48, marginBottom:12}}>🌱</div>
            <p>Aucune annonce publiée.<br />Commencez par enregistrer votre première récolte !</p>
          </div>
        )}
        {harvests.map(h => (
          <div key={h.id} style={S.card}>
            <div style={S.top}>
              <p style={S.product}>{EMOJI[h.productType]||'📦'} {h.productType} — {h.quantityKg} kg</p>
              <span style={S.badge(h.status)}>{STATUS[h.status]?.label||h.status}</span>
            </div>
            <p style={S.detail}>💰 {h.pricePerKgFcfa} FCFA/kg · Total : {(h.quantityKg*h.pricePerKgFcfa).toLocaleString()} FCFA</p>
            <p style={S.detail}>📍 {h.villageName}{h.region ? ` — ${h.region}` : ''}</p>
            {h.qualityCategory && <p style={S.detail}>🤖 Qualité IA : {h.qualityCategory} · Maturité : {h.maturityPercent||'—'}%</p>}
            {h.harvestDate && <p style={S.detail}>📅 Récolté le : {h.harvestDate}</p>}
          </div>
        ))}
      </div>
      <button style={S.addBtn} onClick={() => navigate('/farmer/create')}>+</button>
    </div>
  );
};
export default MyHarvestsPage;
