/**
 * Tableau de bord Agriculteur — complet. RESPONSABLE : R
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getMyHarvests } from '../../api/harvestApi';
import { useAuth } from '../../context/AuthContext';

const PRODUCT_EMOJI = { TOMATO:'🍅', CASSAVA:'🥔', PLANTAIN:'🍌', MACABO:'🌿', AVOCADO:'🥑', PEPPER:'🌶️', ONION:'🧅', OTHER:'📦' };
const STATUS = {
  PENDING_TRANSPORT: { label:'En attente camion', bg:'#FFF3E0', color:'#E65100' },
  GROUPED:           { label:'Groupage validé',   bg:'#E3F2FD', color:'#1565C0' },
  IN_TRANSIT:        { label:'En transit',         bg:'#E8F5E9', color:'#1B7A3E' },
  DELIVERED:         { label:'Livré',              bg:'#F5F5F5', color:'#666'    },
  AT_HUB:            { label:'Au hub',             bg:'#F3E5F5', color:'#6A1B9A' },
};

const S = {
  page: { minHeight:'100vh', background:'#F5F9F6', fontFamily:'Arial,sans-serif' },
  header: { background:'linear-gradient(135deg,#1B7A3E,#145C2E)', color:'#fff', padding:'20px 24px' },
  name: { margin:0, fontSize:22, fontWeight:'bold' },
  stars: { margin:'4px 0 0', fontSize:14, opacity:.9 },
  body: { padding:20 },
  grid: { display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginBottom:24 },
  tile: (color) => ({
    background:color, borderRadius:14, padding:'18px 14px', cursor:'pointer',
    textAlign:'center', boxShadow:'0 2px 8px rgba(0,0,0,.1)', border:'none', width:'100%',
  }),
  tileEmoji: { fontSize:32, display:'block', marginBottom:6 },
  tileLabel: { color:'#fff', fontWeight:'bold', fontSize:14 },
  sectionTitle: { fontWeight:'bold', color:'#333', margin:'0 0 12px' },
  card: { background:'#fff', borderRadius:12, padding:'14px 16px', marginBottom:10, boxShadow:'0 2px 6px rgba(0,0,0,.07)', display:'flex', justifyContent:'space-between', alignItems:'center' },
  cardLeft: {},
  product: { fontWeight:'bold', fontSize:15, color:'#1B7A3E', margin:'0 0 2px' },
  qty: { fontSize:13, color:'#555', margin:0 },
  badge: (s) => ({ padding:'4px 10px', borderRadius:20, fontSize:11, fontWeight:'bold', background: STATUS[s]?.bg||'#eee', color: STATUS[s]?.color||'#333' }),
  empty: { textAlign:'center', color:'#aaa', padding:30, fontSize:14 },
  stars_val: (score) => '⭐'.repeat(Math.round(score||5)) + ` ${(score||5).toFixed(1)}/5`,
};

const FarmerDashboard = () => {
  const [harvests, setHarvests] = useState([]);
  const [loading, setLoading]   = useState(true);
  const { user }                = useAuth();
  const navigate                = useNavigate();

  useEffect(() => {
    getMyHarvests().then(r => setHarvests(r.data)).catch(()=>{}).finally(()=>setLoading(false));
  }, []);

  return (
    <div style={S.page}>
      <div style={S.header}>
        <h2 style={S.name}>👨‍🌾 {user?.name || 'Mon espace agriculteur'}</h2>
        <p style={S.stars}>{S.stars_val(user?.trustScore)} · Note de confiance</p>
      </div>
      <div style={S.body}>
        <div style={S.grid}>
          <button style={S.tile('#1B7A3E')} onClick={() => navigate('/farmer/create')}>
            <span style={S.tileEmoji}>📸</span>
            <span style={S.tileLabel}>Publier une récolte</span>
          </button>
          <button style={S.tile('#2E7D32')} onClick={() => navigate('/farmer/my-harvests')}>
            <span style={S.tileEmoji}>📦</span>
            <span style={S.tileLabel}>Mes annonces</span>
          </button>
          <button style={S.tile('#1565C0')} onClick={() => navigate('/buyer/prices')}>
            <span style={S.tileEmoji}>📊</span>
            <span style={S.tileLabel}>Prix du marché</span>
          </button>
          <button style={S.tile('#6A1B9A')} onClick={() => navigate('/buyer/catalog')}>
            <span style={S.tileEmoji}>🔍</span>
            <span style={S.tileLabel}>Catalogue</span>
          </button>
        </div>

        <p style={S.sectionTitle}>Mes dernières annonces</p>
        {loading && <p style={S.empty}>Chargement...</p>}
        {!loading && harvests.length === 0 && <p style={S.empty}>Aucune annonce. Publiez votre première récolte !</p>}
        {harvests.slice(0,5).map(h => (
          <div key={h.id} style={S.card}>
            <div style={S.cardLeft}>
              <p style={S.product}>{PRODUCT_EMOJI[h.productType]||'📦'} {h.productType} — {h.quantityKg} kg</p>
              <p style={S.qty}>{h.pricePerKgFcfa} FCFA/kg · {h.villageName}</p>
            </div>
            <span style={S.badge(h.status)}>{STATUS[h.status]?.label||h.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
};
export default FarmerDashboard;
