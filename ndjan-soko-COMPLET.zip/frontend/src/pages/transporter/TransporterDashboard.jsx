/**
 * Tableau de bord Transporteur. RESPONSABLE : B
 */
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getMyTrips, validateQrCode } from '../../api/logisticsApi';
import { useAuth } from '../../context/AuthContext';

const STATUS_COLORS = {
  OPEN: { bg: '#E8F5E9', color: '#1B7A3E', label: 'Ouvert' },
  FULL: { bg: '#FFF3E0', color: '#E65100', label: 'Complet' },
  IN_PROGRESS: { bg: '#E3F2FD', color: '#1565C0', label: 'En route' },
  COMPLETED: { bg: '#F5F5F5', color: '#666', label: 'Terminé' },
};

const S = {
  page: { minHeight: '100vh', background: '#F5F9F6', fontFamily: 'Arial, sans-serif' },
  header: { background: '#00695C', color: '#fff', padding: '20px 24px' },
  title: { margin: 0, fontSize: 22, fontWeight: 'bold' },
  sub: { margin: '4px 0 0', fontSize: 13, opacity: 0.85 },
  body: { padding: 20 },
  btn: (color) => ({
    background: color || '#00695C', color: '#fff', border: 'none',
    borderRadius: 12, padding: '12px 20px', fontSize: 15, fontWeight: 'bold',
    cursor: 'pointer', width: '100%', marginBottom: 12,
  }),
  card: {
    background: '#fff', borderRadius: 14, padding: 16,
    marginBottom: 14, boxShadow: '0 2px 8px rgba(0,0,0,0.07)',
  },
  badge: (type) => ({
    display: 'inline-block', padding: '3px 10px', borderRadius: 20, fontSize: 12,
    fontWeight: 'bold', background: STATUS_COLORS[type]?.bg || '#eee',
    color: STATUS_COLORS[type]?.color || '#333',
  }),
  qrRow: { display: 'flex', gap: 10, marginTop: 16 },
  qrInput: {
    flex: 1, padding: '10px 14px', border: '2px solid #e0e0e0',
    borderRadius: 10, fontSize: 15, outline: 'none',
  },
  qrBtn: {
    background: '#00695C', color: '#fff', border: 'none',
    borderRadius: 10, padding: '10px 16px', fontWeight: 'bold', cursor: 'pointer',
  },
  success: { background: '#E8F5E9', color: '#1B7A3E', padding: '10px 14px', borderRadius: 10, marginTop: 10, fontSize: 13 },
  error: { background: '#FFEBEE', color: '#B71C1C', padding: '10px 14px', borderRadius: 10, marginTop: 10, fontSize: 13 },
  empty: { textAlign: 'center', color: '#aaa', padding: 30, fontSize: 14 },
};

const TransporterDashboard = () => {
  const [trips, setTrips]       = useState([]);
  const [qrCode, setQrCode]     = useState('');
  const [msg, setMsg]           = useState({ text: '', type: '' });
  const [loading, setLoading]   = useState(true);
  const { user }                = useAuth();
  const navigate                = useNavigate();

  useEffect(() => {
    getMyTrips()
      .then(r => setTrips(r.data))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const handleScanQr = async () => {
    if (!qrCode.trim()) return;
    try {
      const r = await validateQrCode(qrCode.trim());
      setMsg({ text: r.data, type: 'success' });
      setQrCode('');
    } catch (e) {
      setMsg({ text: e.response?.data || 'QR Code invalide.', type: 'error' });
    }
  };

  const activeTrip = trips.find(t => t.status === 'OPEN' || t.status === 'IN_PROGRESS');

  return (
    <div style={S.page}>
      <div style={S.header}>
        <h2 style={S.title}>🚚 Tableau de bord Transporteur</h2>
        <p style={S.sub}>Bienvenue, {user?.name || 'Chauffeur'}</p>
      </div>

      <div style={S.body}>
        <button style={S.btn()} onClick={() => navigate('/transporter/declare-trip')}>
          ➕ Déclarer un nouveau trajet
        </button>

        {/* Trajet actif */}
        {activeTrip && (
          <div style={{ ...S.card, border: '2px solid #00695C' }}>
            <p style={{ margin: '0 0 6px', fontWeight: 'bold', color: '#00695C' }}>📍 Trajet actif</p>
            <p style={{ margin: '4px 0' }}>{activeTrip.departureCity} → {activeTrip.arrivalCity}</p>
            <p style={{ margin: '4px 0', color: '#555', fontSize: 13 }}>
              Capacité restante : <strong>{activeTrip.availableCapacityKg} kg</strong>
            </p>
            <span style={S.badge(activeTrip.status)}>{STATUS_COLORS[activeTrip.status]?.label}</span>
          </div>
        )}

        {/* Scanner QR Code */}
        <div style={S.card}>
          <p style={{ margin: '0 0 8px', fontWeight: 'bold', color: '#333' }}>📷 Scanner un QR Code de chargement</p>
          <div style={S.qrRow}>
            <input
              style={S.qrInput}
              placeholder="NDJANSOKO-LOT-XXXXXXXX"
              value={qrCode}
              onChange={e => setQrCode(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleScanQr()}
            />
            <button style={S.qrBtn} onClick={handleScanQr}>Valider</button>
          </div>
          {msg.text && <div style={msg.type === 'success' ? S.success : S.error}>{msg.text}</div>}
        </div>

        {/* Historique des trajets */}
        <p style={{ fontWeight: 'bold', color: '#333', margin: '16px 0 10px' }}>Mes trajets</p>
        {loading && <p style={S.empty}>Chargement...</p>}
        {!loading && trips.length === 0 && (
          <p style={S.empty}>Aucun trajet déclaré. Commencez par en déclarer un !</p>
        )}
        {trips.map(t => (
          <div key={t.id} style={S.card}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <strong>{t.departureCity} → {t.arrivalCity}</strong>
              <span style={S.badge(t.status)}>{STATUS_COLORS[t.status]?.label}</span>
            </div>
            <p style={{ margin: '6px 0 0', color: '#555', fontSize: 13 }}>
              {t.totalCapacityKg} kg total · {t.availableCapacityKg} kg disponible · {t.pricePerKgFcfa} FCFA/kg
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};

export default TransporterDashboard;
