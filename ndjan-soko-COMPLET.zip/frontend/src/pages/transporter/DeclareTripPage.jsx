/**
 * Formulaire de déclaration de trajet. RESPONSABLE : B
 */
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { declareTrip } from '../../api/logisticsApi';

const CITIES = ['Bafoussam', 'Douala', 'Yaoundé', 'Foumbot', 'Dschang', 'Bafang', 'Kumba', 'Buéa', 'Ngaoundéré', 'Garoua'];

const S = {
  page: { minHeight: '100vh', background: '#F5F9F6', fontFamily: 'Arial, sans-serif' },
  header: { background: '#00695C', color: '#fff', padding: '20px 24px', display: 'flex', alignItems: 'center', gap: 12 },
  back: { background: 'none', border: 'none', color: '#fff', fontSize: 20, cursor: 'pointer' },
  title: { margin: 0, fontSize: 20, fontWeight: 'bold' },
  body: { padding: 20, maxWidth: 480, margin: '0 auto' },
  label: { display: 'block', fontWeight: 'bold', fontSize: 14, color: '#333', margin: '16px 0 6px' },
  input: { width: '100%', padding: '11px 14px', border: '2px solid #e0e0e0', borderRadius: 10, fontSize: 15, outline: 'none', boxSizing: 'border-box' },
  select: { width: '100%', padding: '11px 14px', border: '2px solid #e0e0e0', borderRadius: 10, fontSize: 15, outline: 'none', background: '#fff', boxSizing: 'border-box' },
  row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 },
  btn: { width: '100%', padding: 14, marginTop: 24, background: '#00695C', color: '#fff', border: 'none', borderRadius: 12, fontSize: 16, fontWeight: 'bold', cursor: 'pointer' },
  error: { background: '#FFEBEE', color: '#B71C1C', padding: '10px 14px', borderRadius: 10, fontSize: 13, marginTop: 12 },
  success: { background: '#E8F5E9', color: '#1B7A3E', padding: '12px 16px', borderRadius: 10, fontSize: 14, marginTop: 16 },
};

const DeclareTripPage = () => {
  const [form, setForm]         = useState({
    departureCity: '', arrivalCity: '', departureTime: '',
    totalCapacityKg: '', availableCapacityKg: '', pricePerKgFcfa: '',
  });
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');
  const [success, setSuccess]   = useState('');
  const navigate                = useNavigate();

  const set = (key, val) => setForm(f => ({ ...f, [key]: val }));

  const handleSubmit = async () => {
    setError('');
    if (!form.departureCity || !form.arrivalCity || !form.departureTime
        || !form.totalCapacityKg || !form.availableCapacityKg || !form.pricePerKgFcfa) {
      setError('Tous les champs sont obligatoires.');
      return;
    }
    if (parseFloat(form.availableCapacityKg) > parseFloat(form.totalCapacityKg)) {
      setError("L'espace disponible ne peut pas dépasser la capacité totale.");
      return;
    }
    setLoading(true);
    try {
      await declareTrip({
        departureCity: form.departureCity,
        arrivalCity: form.arrivalCity,
        departureTime: new Date(form.departureTime).toISOString(),
        totalCapacityKg: parseFloat(form.totalCapacityKg),
        availableCapacityKg: parseFloat(form.availableCapacityKg),
        pricePerKgFcfa: parseFloat(form.pricePerKgFcfa),
      });
      setSuccess('✅ Trajet déclaré ! L\'algorithme de groupage a été lancé. Des lots peuvent déjà vous être proposés.');
      setTimeout(() => navigate('/transporter'), 2500);
    } catch (e) {
      setError(e.response?.data || 'Erreur réseau. Réessayez.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.page}>
      <div style={S.header}>
        <button style={S.back} onClick={() => navigate('/transporter')}>←</button>
        <h2 style={S.title}>🗺️ Déclarer mon trajet</h2>
      </div>
      <div style={S.body}>
        {error   && <div style={S.error}>⚠️ {error}</div>}
        {success && <div style={S.success}>{success}</div>}

        <div style={S.row}>
          <div>
            <label style={S.label}>Ville de départ</label>
            <select style={S.select} value={form.departureCity} onChange={e => set('departureCity', e.target.value)}>
              <option value="">Choisir...</option>
              {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label style={S.label}>Ville d'arrivée</label>
            <select style={S.select} value={form.arrivalCity} onChange={e => set('arrivalCity', e.target.value)}>
              <option value="">Choisir...</option>
              {CITIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <label style={S.label}>Date et heure de départ</label>
        <input style={S.input} type="datetime-local" value={form.departureTime} onChange={e => set('departureTime', e.target.value)} />

        <div style={S.row}>
          <div>
            <label style={S.label}>Capacité totale (kg)</label>
            <input style={S.input} type="number" placeholder="10000" value={form.totalCapacityKg} onChange={e => set('totalCapacityKg', e.target.value)} />
          </div>
          <div>
            <label style={S.label}>Espace disponible (kg)</label>
            <input style={S.input} type="number" placeholder="4000" value={form.availableCapacityKg} onChange={e => set('availableCapacityKg', e.target.value)} />
          </div>
        </div>

        <label style={S.label}>Prix par kg (FCFA)</label>
        <input style={S.input} type="number" placeholder="50" value={form.pricePerKgFcfa} onChange={e => set('pricePerKgFcfa', e.target.value)} />

        <div style={{ background: '#E0F2F1', borderRadius: 10, padding: '12px 16px', marginTop: 20 }}>
          <p style={{ margin: 0, fontSize: 13, color: '#00695C' }}>
            💡 Après validation, l'algorithme de groupage se lance automatiquement et vous propose les lots disponibles sur votre itinéraire.
          </p>
        </div>

        <button style={S.btn} onClick={handleSubmit} disabled={loading}>
          {loading ? 'Enregistrement...' : '✅ Déclarer ce trajet'}
        </button>
      </div>
    </div>
  );
};

export default DeclareTripPage;
