/**
 * Page de sélection du rôle — première inscription.
 * RESPONSABLE : F
 */
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { sendOtp, verifyOtp } from '../../api/authApi';
import { useAuth } from '../../context/AuthContext';

// ─── Données des rôles ────────────────────────────────────────────────────────
const ROLES = [
  {
    key: 'FARMER',
    emoji: '🌱',
    label: 'Agriculteur',
    sublabel: 'GIC / Producteur',
    desc: 'Publiez vos récoltes, trouvez un camion et recevez votre argent en sécurité.',
    color: '#1B7A3E',
    bg: '#E8F5E9',
  },
  {
    key: 'BUYER',
    emoji: '🛒',
    label: 'Acheteur',
    sublabel: 'Bayam-Sellam / Grossiste / Supermarché',
    desc: 'Consultez les prix du marché, achetez à la source et suivez vos livraisons.',
    color: '#1565C0',
    bg: '#E3F2FD',
  },
  {
    key: 'TRANSPORTER',
    emoji: '🚚',
    label: 'Transporteur',
    sublabel: 'Chauffeur de camion',
    desc: "Déclarez votre trajet, rentabilisez l'espace vide et trouvez des lots.",
    color: '#00695C',
    bg: '#E0F2F1',
  },
  {
    key: 'HUB_MANAGER',
    emoji: '🏪',
    label: 'Gérant Hub',
    sublabel: 'Entrepôt partenaire',
    desc: 'Réceptionnez les marchandises, scannez les QR codes et gérez le stock.',
    color: '#6A1B9A',
    bg: '#F3E5F5',
  },
];

// ─── Styles ───────────────────────────────────────────────────────────────────
const S = {
  page: {
    minHeight: '100vh', background: 'linear-gradient(135deg, #1B7A3E 0%, #145C2E 100%)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontFamily: 'Arial, sans-serif', padding: 20,
  },
  card: {
    background: '#fff', borderRadius: 20, padding: '36px 30px',
    maxWidth: 480, width: '100%', boxShadow: '0 20px 60px rgba(0,0,0,0.25)',
  },
  logo:     { fontSize: 40, textAlign: 'center', marginBottom: 4 },
  title:    { textAlign: 'center', color: '#1B7A3E', fontSize: 22, fontWeight: 'bold', margin: '0 0 4px' },
  subtitle: { textAlign: 'center', color: '#888', fontSize: 13, margin: '0 0 24px' },
  grid:     { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 },
  roleCard: (selected, color, bg) => ({
    border: `2.5px solid ${selected ? color : '#e0e0e0'}`,
    borderRadius: 14, padding: '16px 12px', cursor: 'pointer',
    background: selected ? bg : '#fafafa',
    textAlign: 'center', transition: 'all .2s',
    transform: selected ? 'scale(1.03)' : 'scale(1)',
    boxShadow: selected ? `0 4px 16px ${color}33` : 'none',
  }),
  roleEmoji:   { fontSize: 32, marginBottom: 6 },
  roleLabel:   (selected, color) => ({ fontWeight: 'bold', fontSize: 15, color: selected ? color : '#333' }),
  roleSub:     { fontSize: 11, color: '#888', marginTop: 2 },
  roleDesc:    (selected, color) => ({ fontSize: 12, color: selected ? color : '#aaa', marginTop: 6, lineHeight: 1.4 }),
  label:       { display: 'block', color: '#333', fontWeight: 'bold', fontSize: 14, marginBottom: 6 },
  input: {
    width: '100%', padding: '13px 16px', fontSize: 18, border: '2px solid #e0e0e0',
    borderRadius: 12, outline: 'none', boxSizing: 'border-box',
  },
  btn: (active) => ({
    width: '100%', padding: 14, marginTop: 16, background: active ? '#1B7A3E' : '#ccc',
    color: '#fff', border: 'none', borderRadius: 12, fontSize: 16,
    fontWeight: 'bold', cursor: active ? 'pointer' : 'not-allowed', transition: 'all .2s',
  }),
  error:   { background: '#FFEBEE', color: '#B71C1C', padding: '10px 14px', borderRadius: 10, fontSize: 13, marginTop: 12 },
  success: { background: '#E8F5E9', color: '#1B7A3E', padding: '10px 14px', borderRadius: 10, fontSize: 13, marginTop: 12 },
  back:    { background: 'none', border: 'none', color: '#1B7A3E', cursor: 'pointer', fontSize: 13, marginTop: 12, display: 'block', textAlign: 'center' },
  otpRow:  { display: 'flex', gap: 10, justifyContent: 'center', margin: '14px 0' },
  otpBox:  (filled) => ({
    width: 44, height: 54, textAlign: 'center', fontSize: 22, fontWeight: 'bold',
    border: `2px solid ${filled ? '#1B7A3E' : '#e0e0e0'}`, borderRadius: 12,
    outline: 'none', color: '#1B7A3E', background: filled ? '#E8F5E9' : '#fff',
  }),
};

// ─── Composant ────────────────────────────────────────────────────────────────
const RegisterRolePage = () => {
  const [step, setStep]       = useState(1);   // 1=rôle, 2=téléphone, 3=OTP
  const [role, setRole]       = useState('');
  const [phone, setPhone]     = useState('');
  const [otp, setOtp]         = useState(Array(6).fill(''));
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');
  const [info, setInfo]       = useState('');
  const inputRefs             = React.useRef([]);

  const { login } = useAuth();
  const navigate  = useNavigate();

  // ── Étape 1 → 2 : confirmer le rôle ────────────────────────────────────────
  const handleConfirmRole = () => {
    if (!role) { setError('Veuillez choisir votre rôle.'); return; }
    setError(''); setStep(2);
  };

  // ── Étape 2 → 3 : envoyer l'OTP ────────────────────────────────────────────
  const handleSendOtp = async () => {
    setError(''); setInfo('');
    const cleaned = phone.replace(/\s/g, '');
    if (!/^(237)?[67][0-9]{8}$/.test(cleaned)) {
      setError('Numéro invalide. Format : 6XXXXXXXX ou 2376XXXXXXXX');
      return;
    }
    setLoading(true);
    try {
      await sendOtp(cleaned);
      setInfo('Code envoyé (voir les logs serveur en développement).');
      setStep(3);
    } catch (e) {
      setError(e.response?.data || 'Erreur réseau.');
    } finally {
      setLoading(false);
    }
  };

  // ── Étape 3 : saisie OTP ────────────────────────────────────────────────────
  const handleOtpChange = (i, value) => {
    const digit = value.replace(/\D/g, '').slice(-1);
    const next  = [...otp]; next[i] = digit; setOtp(next);
    if (digit && i < 5) inputRefs.current[i + 1]?.focus();
    if (next.every(d => d !== '') && digit) handleVerify(next.join(''));
  };

  const handleOtpKeyDown = (i, e) => {
    if (e.key === 'Backspace' && !otp[i] && i > 0) inputRefs.current[i - 1]?.focus();
  };

  // ── Étape 3 : vérification + création compte ────────────────────────────────
  const handleVerify = async (code) => {
    setError(''); setLoading(true);
    try {
      const { data: token } = await verifyOtp(phone.replace(/\s/g, ''), code, role);
      login(token);
      navigate('/');
    } catch (e) {
      setError(e.response?.data || 'Code incorrect ou expiré.');
      setOtp(Array(6).fill(''));
      setTimeout(() => inputRefs.current[0]?.focus(), 100);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={S.page}>
      <div style={S.card}>
        <div style={S.logo}>🌿</div>
        <h1 style={S.title}>Bienvenue sur Ndjan-Soko</h1>
        <p style={S.subtitle}>Création de compte — Étape {step}/3</p>

        {error   && <div style={S.error}>⚠️ {error}</div>}
        {info    && <div style={S.success}>✅ {info}</div>}

        {/* ── Étape 1 : choix du rôle ── */}
        {step === 1 && (
          <>
            <p style={{ color: '#555', fontSize: 14, textAlign: 'center', margin: '0 0 16px' }}>
              Je suis un(e)…
            </p>
            <div style={S.grid}>
              {ROLES.map(r => (
                <div
                  key={r.key}
                  style={S.roleCard(role === r.key, r.color, r.bg)}
                  onClick={() => { setRole(r.key); setError(''); }}
                >
                  <div style={S.roleEmoji}>{r.emoji}</div>
                  <div style={S.roleLabel(role === r.key, r.color)}>{r.label}</div>
                  <div style={S.roleSub}>{r.sublabel}</div>
                  <div style={S.roleDesc(role === r.key, r.color)}>{r.desc}</div>
                </div>
              ))}
            </div>
            <button style={S.btn(!!role)} onClick={handleConfirmRole} disabled={!role}>
              Continuer →
            </button>
            <button style={S.back} onClick={() => navigate('/login')}>
              ← J'ai déjà un compte
            </button>
          </>
        )}

        {/* ── Étape 2 : numéro de téléphone ── */}
        {step === 2 && (
          <>
            <p style={{ color: '#555', fontSize: 14, textAlign: 'center', marginBottom: 16 }}>
              Vous vous inscrivez comme{' '}
              <strong style={{ color: ROLES.find(r => r.key === role)?.color }}>
                {ROLES.find(r => r.key === role)?.emoji} {ROLES.find(r => r.key === role)?.label}
              </strong>
            </p>
            <label style={S.label}>Numéro MTN ou Orange</label>
            <input
              style={S.input}
              type="tel"
              placeholder="670 000 000"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendOtp()}
              autoFocus
            />
            <button style={S.btn(!loading)} onClick={handleSendOtp} disabled={loading}>
              {loading ? 'Envoi...' : '📲 Recevoir le code SMS'}
            </button>
            <button style={S.back} onClick={() => { setStep(1); setError(''); setInfo(''); }}>
              ← Changer de rôle
            </button>
          </>
        )}

        {/* ── Étape 3 : code OTP ── */}
        {step === 3 && (
          <>
            <p style={{ color: '#555', fontSize: 14, textAlign: 'center', marginBottom: 8 }}>
              Code envoyé au <strong>{phone}</strong>
            </p>
            <div style={S.otpRow}>
              {otp.map((d, i) => (
                <input
                  key={i}
                  ref={el => (inputRefs.current[i] = el)}
                  style={S.otpBox(!!d)}
                  type="text"
                  inputMode="numeric"
                  maxLength={2}
                  value={d}
                  onChange={e => handleOtpChange(i, e.target.value)}
                  onKeyDown={e => handleOtpKeyDown(i, e)}
                  autoFocus={i === 0}
                />
              ))}
            </div>
            {loading && <p style={{ textAlign: 'center', color: '#1B7A3E' }}>Création du compte...</p>}
            <button style={S.back} onClick={() => { setStep(2); setOtp(Array(6).fill('')); setError(''); setInfo(''); }}>
              ← Renvoyer le code
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default RegisterRolePage;
