/**
 * Panneau Admin — Registre SHA-256 + Simulateur USSD Nokia. RESPONSABLE : A
 */
import React, { useState, useRef } from 'react';
import { verifyChain } from '../../api/paymentApi';
import apiClient from '../../api/apiClient';

const S = {
  page: { minHeight: '100vh', background: '#1A1A2E', fontFamily: 'Arial, sans-serif', padding: 24 },
  title: { color: '#E8F5E9', fontSize: 26, fontWeight: 'bold', margin: '0 0 24px' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 },
  card: { background: '#16213E', borderRadius: 16, padding: 24 },
  cardTitle: { color: '#81C784', fontSize: 17, fontWeight: 'bold', margin: '0 0 16px' },
  btn: (color) => ({
    padding: '11px 20px', background: color || '#1B7A3E', color: '#fff',
    border: 'none', borderRadius: 10, fontWeight: 'bold', cursor: 'pointer',
    fontSize: 14, width: '100%', marginBottom: 12,
  }),
  resultOk:  { background: '#1B5E20', color: '#A5D6A7', padding: '12px 16px', borderRadius: 10, fontSize: 14, marginTop: 12, fontFamily: 'monospace' },
  resultErr: { background: '#B71C1C', color: '#FFCDD2', padding: '12px 16px', borderRadius: 10, fontSize: 14, marginTop: 12, fontFamily: 'monospace' },
  // Nokia
  phone: { width: 220, margin: '0 auto', background: '#2C2C2C', borderRadius: 24, padding: '16px 14px', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' },
  screen: { background: '#111', borderRadius: 10, padding: 12, minHeight: 130, marginBottom: 12 },
  screenText: { color: '#00FF7F', fontFamily: 'monospace', fontSize: 13, whiteSpace: 'pre-wrap', lineHeight: 1.5 },
  phoneNum: { color: '#888', fontSize: 11, fontFamily: 'monospace', marginBottom: 6 },
  keyGrid: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 },
  key: { background: '#444', color: '#eee', border: 'none', borderRadius: 8, padding: '10px 6px', fontSize: 14, fontWeight: 'bold', cursor: 'pointer', textAlign: 'center' },
  keySpecial: { background: '#6A1B9A', color: '#fff', border: 'none', borderRadius: 8, padding: '10px 6px', fontSize: 13, fontWeight: 'bold', cursor: 'pointer', textAlign: 'center' },
  phoneInput: { width: '100%', background: '#1A1A1A', border: '1px solid #444', borderRadius: 8, padding: '8px 10px', color: '#fff', fontSize: 13, marginBottom: 10, boxSizing: 'border-box' },
};

const KEYS = ['1','2','3','4','5','6','7','8','9','*','0','#'];

const AdminSecurityPage = () => {
  const [chainResult, setChainResult]   = useState('');
  const [chainOk, setChainOk]           = useState(null);
  const [chainLoading, setChainLoading] = useState(false);

  // USSD
  const [simPhone, setSimPhone]         = useState('670000001');
  const [ussdText, setUssdText]         = useState('');
  const [screen, setScreen]             = useState('Appuyez sur * pour démarrer\nla simulation USSD');
  const [sessionId]                     = useState('SIM-' + Date.now());
  const [sessionActive, setSessionActive] = useState(false);

  const handleVerify = async () => {
    setChainLoading(true); setChainResult('');
    try {
      const r = await verifyChain();
      setChainOk(true); setChainResult(r.data);
    } catch (e) {
      setChainOk(false); setChainResult(e.response?.data || 'Erreur de connexion au serveur.');
    } finally { setChainLoading(false); }
  };

  const handleKey = async (key) => {
    let newText = '';

    if (key === '#') {
      // Touche # = effacer / retour
      setUssdText(''); setScreen('Session réinitialisée.\nAppuyez sur * pour redémarrer.'); setSessionActive(false);
      return;
    }

    if (key === '*' && !sessionActive) {
      // Démarrage de session
      newText = '';
      setSessionActive(true);
    } else if (sessionActive) {
      newText = ussdText === '' ? key : ussdText + '*' + key;
    } else {
      return;
    }

    setUssdText(newText);

    try {
      const res = await apiClient.post('/ussd', null, {
        params: { sessionId, phoneNumber: simPhone, text: newText }
      });
      const response = res.data || '';
      const displayText = response.replace(/^(CON |END )/, '');
      setScreen(displayText);
      if (response.startsWith('END')) {
        setSessionActive(false); setUssdText('');
      }
    } catch (e) {
      setScreen('Erreur de connexion au serveur.\nVérifiez que le backend tourne sur :8080');
      setSessionActive(false);
    }
  };

  return (
    <div style={S.page}>
      <h2 style={S.title}>🛡️ Panneau d'Administration</h2>

      <div style={S.grid}>

        {/* ── Section 1 : Registre SHA-256 ── */}
        <div style={S.card}>
          <p style={S.cardTitle}>🔗 Registre SHA-256 — Anti-Fraude</p>
          <p style={{ color: '#90A4AE', fontSize: 13, marginBottom: 16, lineHeight: 1.5 }}>
            Vérifie que chaque transaction est correctement enchaînée à la précédente.
            Toute modification frauduleuse en base de données brise la chaîne et déclenche une alerte.
          </p>
          <button style={S.btn()} onClick={handleVerify} disabled={chainLoading}>
            {chainLoading ? '⏳ Vérification en cours...' : '🔍 Vérifier l\'intégrité de la chaîne'}
          </button>
          {chainResult && (
            <div style={chainOk ? S.resultOk : S.resultErr}>
              {chainResult}
            </div>
          )}
        </div>

        {/* ── Section 2 : Simulateur USSD Nokia ── */}
        <div style={S.card}>
          <p style={S.cardTitle}>📱 Simulateur USSD — Téléphone Basique</p>
          <p style={{ color: '#90A4AE', fontSize: 12, marginBottom: 12 }}>Numéro simulé :</p>
          <input
            style={S.phoneInput}
            value={simPhone}
            onChange={e => setSimPhone(e.target.value)}
            placeholder="670000001"
          />

          <div style={S.phone}>
            <div style={S.screen}>
              <p style={S.phoneNum}>📶 MTN CM | {simPhone}</p>
              <p style={S.screenText}>{screen}</p>
            </div>
            <div style={S.keyGrid}>
              {KEYS.map(k => (
                <button
                  key={k}
                  style={k === '*' || k === '#' ? S.keySpecial : S.key}
                  onClick={() => handleKey(k)}
                >
                  {k === '#' ? '# Effacer' : k}
                </button>
              ))}
            </div>
          </div>

          <p style={{ color: '#546E7A', fontSize: 11, textAlign: 'center', marginTop: 10 }}>
            * = Démarrer · # = Effacer · Naviguez avec 1, 2, 3...
          </p>
        </div>

      </div>
    </div>
  );
};

export default AdminSecurityPage;
